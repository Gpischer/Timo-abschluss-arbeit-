# 🔧 BACKEND - PHP REST API

Das Backend ist eine REST API in PHP 8.2+ mit MySQL-Datenbank.

## 📁 Struktur

```
backend/
├── api/
│   ├── auth.php         # Login/Logout/Check
│   ├── auftraege.php    # CRUD für Serviceaufträge
│   ├── users.php        # Benutzerverwaltung
│   └── pdf.php          # PDF-Generierung
├── config/
│   └── database.php     # DB-Verbindung
├── models/
│   ├── User.php         # User-Model
│   └── Auftrag.php      # Auftrags-Model
└── .htaccess            # Apache-Konfiguration
```

## 🚀 Start

```bash
cd backend
php -S localhost:8000
```

## 📡 API-Endpoints

### Authentifizierung

```
POST /api/auth.php?action=login
GET  /api/auth.php?action=logout
GET  /api/auth.php?action=check
```

### Aufträge

```
GET    /api/auftraege.php              # Alle Aufträge
GET    /api/auftraege.php?id=1         # Ein Auftrag
POST   /api/auftraege.php              # Neuer Auftrag
PUT    /api/auftraege.php              # Auftrag ändern
DELETE /api/auftraege.php?id=1         # Auftrag löschen
```

### Status-Änderungen

```
POST /api/auftraege.php?action=disponieren
POST /api/auftraege.php?action=rapport
POST /api/auftraege.php?action=freigeben
POST /api/auftraege.php?action=verrechnen
```

### PDF

```
GET /api/pdf.php?id=1    # PDF für Auftrag generieren
```

## 🔐 Authentifizierung

Session-basiert mit Token im Cookie.

## ⚙️ Konfiguration

Siehe `.env.example` und kopiere zu `.env`:

```bash
DB_HOST=localhost
DB_NAME=glauser_serviceauftrag
DB_USER=root
DB_PASSWORD=
```

## 📦 Dependencies

- PHP 8.2+
- MySQL 8.0+
- Extensions: PDO, pdo_mysql, session, json
