# ⚛️ FRONTEND - React App

Das Frontend ist eine Single Page Application in React 18.3.

## 📁 Struktur

```
frontend/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── Login.js
│   │   ├── OrderList.js
│   │   ├── OrderDetail.js
│   │   ├── OrderForm.js
│   │   └── ...
│   ├── App.js
│   ├── App.css
│   └── index.js
├── package.json
└── .env
```

## 🚀 Start

```bash
cd frontend
npm install
npm start
```

Öffnet automatisch http://localhost:3000

## 📦 Dependencies

- React 18.3.1
- React Router 6.x
- Axios (HTTP Client)

## ⚙️ Konfiguration

Siehe `.env.example`:

```bash
REACT_APP_API_URL=http://localhost:8000
```

## 🎨 Features

- Login/Logout
- Dashboard mit Statistiken
- Auftragsverwaltung (CRUD)
- Filter & Suche
- PDF-Export
- Responsive Design
