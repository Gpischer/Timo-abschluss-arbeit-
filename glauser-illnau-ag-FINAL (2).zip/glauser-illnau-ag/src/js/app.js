// =====================================================
// Glauser Illnau AG - Hauptapplikation (JavaScript)
// =====================================================

// Globale Variablen
let alleAuftraege = [];
let alleMitarbeiter = [];
let aktuellerFilter = '';
let aktuellesSuchwort = '';

// =====================================================
// Initialisierung
// =====================================================
document.addEventListener('DOMContentLoaded', () => {
    console.log('Applikation gestartet...');
    
    // Event Listeners registrieren
    registriereEventListeners();
    
    // Daten laden
    ladeMitarbeiter();
    ladeAuftraege();
    
    // Aktuelles Datum und Zeit setzen
    setzeAktuellesDatumZeit();
});

// =====================================================
// Event Listeners
// =====================================================
function registriereEventListeners() {
    // Neuer Auftrag Button
    document.getElementById('btnNeuerAuftrag').addEventListener('click', () => {
        oeffneModal('modalNeuerAuftrag');
        setzeAktuellesDatumZeit();
    });
    
    // Modal schließen Buttons
    document.getElementById('closeModalNeuerAuftrag').addEventListener('click', () => {
        schliesseModal('modalNeuerAuftrag');
    });
    document.getElementById('closeModalDetails').addEventListener('click', () => {
        schliesseModal('modalAuftragDetails');
    });
    document.getElementById('closeModalDisponieren').addEventListener('click', () => {
        schliesseModal('modalDisponieren');
    });
    
    // Abbrechen Buttons
    document.getElementById('btnAbbrechen').addEventListener('click', () => {
        schliesseModal('modalNeuerAuftrag');
    });
    document.getElementById('btnAbbrechenDisp').addEventListener('click', () => {
        schliesseModal('modalDisponieren');
    });
    
    // Forms
    document.getElementById('formNeuerAuftrag').addEventListener('submit', speichereNeuerAuftrag);
    document.getElementById('formDisponieren').addEventListener('submit', speichereDisponierung);
    
    // Filter und Suche
    document.getElementById('filterStatus').addEventListener('change', (e) => {
        aktuellerFilter = e.target.value;
        filtereAuftraege();
    });
    
    document.getElementById('searchInput').addEventListener('input', (e) => {
        aktuellesSuchwort = e.target.value.toLowerCase();
        filtereAuftraege();
    });
    
    // Checkbox Toggle für Adressen
    document.getElementById('objektAdresseGleich').addEventListener('change', (e) => {
        document.getElementById('objektAdresseGroup').style.display = e.target.checked ? 'none' : 'block';
    });
    
    document.getElementById('verrAdresseGleich').addEventListener('change', (e) => {
        document.getElementById('verrAdresseGroup').style.display = e.target.checked ? 'none' : 'block';
    });
    
    // Modal außerhalb klicken = schließen
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.classList.remove('show');
        }
    });
    
    // Input Validierung
    document.getElementById('kundePlz').addEventListener('input', (e) => {
        validiereNummerischesEingabefeld(e.target, 4);
    });
}

// =====================================================
// Daten laden (AJAX)
// =====================================================
function ladeAuftraege() {
    zeigeLoader(true);
    
    fetch('php/api.php?action=getAuftraege')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alleAuftraege = data.data;
                zeigeAuftraege(alleAuftraege);
                aktualisiereStatistik();
            } else {
                zeigeToast('Fehler beim Laden der Aufträge', 'error');
            }
        })
        .catch(error => {
            console.error('Fehler:', error);
            zeigeToast('Verbindungsfehler', 'error');
        })
        .finally(() => {
            zeigeLoader(false);
        });
}

function ladeMitarbeiter() {
    fetch('php/api.php?action=getMitarbeiter')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alleMitarbeiter = data.data;
                fuelleMitarbeiterDropdown();
            }
        })
        .catch(error => {
            console.error('Fehler beim Laden der Mitarbeiter:', error);
        });
}

// =====================================================
// Aufträge anzeigen
// =====================================================
function zeigeAuftraege(auftraege) {
    const tbody = document.getElementById('auftragsTableBody');
    const emptyState = document.getElementById('emptyState');
    
    tbody.innerHTML = '';
    
    if (auftraege.length === 0) {
        document.getElementById('auftragsTable').style.display = 'none';
        emptyState.style.display = 'block';
        return;
    }
    
    document.getElementById('auftragsTable').style.display = 'table';
    emptyState.style.display = 'none';
    
    auftraege.forEach(auftrag => {
        const row = erstelleAuftragZeile(auftrag);
        tbody.appendChild(row);
    });
}

function erstelleAuftragZeile(auftrag) {
    const tr = document.createElement('tr');
    
    const statusClass = `status-${auftrag.status}`;
    const statusText = formatiereStatus(auftrag.status);
    const datum = formatiereDatum(auftrag.datum);
    const zeit = formatiereZeit(auftrag.zeit);
    const termin = auftrag.termin ? formatiereDatum(auftrag.termin) : '-';
    const mitarbeiter = auftrag.mitarbeiter_name || '-';
    
    tr.innerHTML = `
        <td><strong>${auftrag.auftrag_id}</strong></td>
        <td>${datum}</td>
        <td>${zeit}</td>
        <td>${htmlEncode(auftrag.kunde_name)}</td>
        <td>${kuerzenText(htmlEncode(auftrag.beschreibung), 50)}</td>
        <td><span class="status-badge ${statusClass}">${statusText}</span></td>
        <td>${htmlEncode(mitarbeiter)}</td>
        <td>${termin}</td>
        <td>
            <div class="action-buttons">
                <button class="btn btn-sm btn-primary" onclick="zeigeDetails(${auftrag.auftrag_id})">
                    Details
                </button>
                ${erstelleAktionsButtons(auftrag)}
            </div>
        </td>
    `;
    
    return tr;
}

function erstelleAktionsButtons(auftrag) {
    let buttons = '';
    
    switch (auftrag.status) {
        case 'erfasst':
            buttons += `
                <button class="btn btn-sm btn-warning" onclick="oeffneDisponierenModal(${auftrag.auftrag_id})">
                    Disponieren
                </button>
            `;
            break;
        case 'disponiert':
            buttons += `
                <button class="btn btn-sm btn-success" onclick="aendereStatus(${auftrag.auftrag_id}, 'ausgefuehrt')">
                    Ausgeführt
                </button>
            `;
            break;
        case 'ausgefuehrt':
            buttons += `
                <button class="btn btn-sm btn-success" onclick="aendereStatus(${auftrag.auftrag_id}, 'freigegeben')">
                    Freigeben
                </button>
            `;
            break;
        case 'freigegeben':
            buttons += `
                <button class="btn btn-sm btn-success" onclick="aendereStatus(${auftrag.auftrag_id}, 'verrechnet')">
                    Verrechnen
                </button>
            `;
            break;
    }
    
    // Drucken/PDF Button IMMER anzeigen (auch bei verrechnet)
    buttons += `
        <button class="btn btn-sm btn-secondary" onclick="druckeAuftrag(${auftrag.auftrag_id})">
            📄 Druck/PDF
        </button>
    `;
    
    return buttons;
}

// =====================================================
// Auftrag Details anzeigen
// =====================================================
function zeigeDetails(auftragId) {
    const auftrag = alleAuftraege.find(a => a.auftrag_id === auftragId);
    
    if (!auftrag) {
        zeigeToast('Auftrag nicht gefunden', 'error');
        return;
    }
    
    document.getElementById('detailAuftragNr').textContent = auftrag.auftrag_id;
    
    const arbeiten = [];
    if (auftrag.arbeiten_reparatur) arbeiten.push('Reparatur');
    if (auftrag.arbeiten_sanitaer) arbeiten.push('Sanitär');
    if (auftrag.arbeiten_heizung) arbeiten.push('Heizung');
    if (auftrag.arbeiten_garantie) arbeiten.push('Garantie');
    
    const detailsHTML = `
        <div class="detail-grid">
            <div class="detail-item">
                <label>Datum</label>
                <div class="value">${formatiereDatum(auftrag.datum)}</div>
            </div>
            <div class="detail-item">
                <label>Zeit</label>
                <div class="value">${formatiereZeit(auftrag.zeit)}</div>
            </div>
            <div class="detail-item">
                <label>Status</label>
                <div class="value">
                    <span class="status-badge status-${auftrag.status}">
                        ${formatiereStatus(auftrag.status)}
                    </span>
                </div>
            </div>
            <div class="detail-item">
                <label>Erstellt am</label>
                <div class="value">${formatiereDatumZeit(auftrag.erstellt_am)}</div>
            </div>
        </div>
        
        <h3 class="form-section-title">Kunde</h3>
        <div class="detail-grid">
            <div class="detail-item detail-full">
                <label>Name</label>
                <div class="value">${htmlEncode(auftrag.kunde_name)}</div>
            </div>
            <div class="detail-item detail-full">
                <label>Adresse</label>
                <div class="value">${htmlEncode(auftrag.kunde_adresse)}</div>
            </div>
            <div class="detail-item">
                <label>PLZ / Ort</label>
                <div class="value">${htmlEncode(auftrag.kunde_plz)} ${htmlEncode(auftrag.kunde_ort)}</div>
            </div>
            <div class="detail-item">
                <label>Telefon</label>
                <div class="value">${htmlEncode(auftrag.kunde_telefon || '-')}</div>
            </div>
            <div class="detail-item">
                <label>Natel</label>
                <div class="value">${htmlEncode(auftrag.kunde_natel || '-')}</div>
            </div>
        </div>
        
        <h3 class="form-section-title">Auftrag</h3>
        <div class="detail-grid">
            <div class="detail-item">
                <label>Objektadresse</label>
                <div class="value">${htmlEncode(auftrag.objekt_adresse || 'dito')}</div>
            </div>
            <div class="detail-item">
                <label>Verrechnungsadresse</label>
                <div class="value">${htmlEncode(auftrag.verrechnung_adresse || 'dito')}</div>
            </div>
            <div class="detail-item detail-full">
                <label>Auszuführende Arbeiten</label>
                <div class="value">${arbeiten.join(', ') || '-'}</div>
            </div>
            <div class="detail-item detail-full">
                <label>Beschreibung</label>
                <div class="value">${htmlEncode(auftrag.beschreibung)}</div>
            </div>
            <div class="detail-item">
                <label>Terminwunsch</label>
                <div class="value">${htmlEncode(auftrag.termin_wunsch || '-')}</div>
            </div>
            ${auftrag.mitarbeiter_name ? `
                <div class="detail-item">
                    <label>Zugewiesener Mitarbeiter</label>
                    <div class="value">${htmlEncode(auftrag.mitarbeiter_name)}</div>
                </div>
            ` : ''}
            ${auftrag.termin ? `
                <div class="detail-item">
                    <label>Geplanter Termin</label>
                    <div class="value">${formatiereDatum(auftrag.termin)}</div>
                </div>
            ` : ''}
        </div>
        
        <div class="form-actions">
            <button class="btn btn-secondary" onclick="schliesseModal('modalAuftragDetails')">
                Schließen
            </button>
            <button class="btn btn-primary" onclick="druckeAuftrag(${auftrag.auftrag_id})">
                🖨️ Drucken / PDF
            </button>
        </div>
    `;
    
    document.getElementById('detailsContent').innerHTML = detailsHTML;
    oeffneModal('modalAuftragDetails');
}

// =====================================================
// Neuen Auftrag speichern
// =====================================================
function speichereNeuerAuftrag(e) {
    e.preventDefault();
    
    // Validierung
    if (!validiereAuftragFormular()) {
        return;
    }
    
    // Formulardaten sammeln
    const formData = new FormData(e.target);
    
    // Arbeiten als Array
    const arbeiten = [];
    document.querySelectorAll('input[name="arbeiten[]"]:checked').forEach(cb => {
        arbeiten.push(cb.value);
    });
    
    const auftragData = {
        datum: formData.get('datum'),
        zeit: formData.get('zeit'),
        kunde: {
            name: formData.get('kundeName'),
            adresse: formData.get('kundeAdresse'),
            plz: formData.get('kundePlz'),
            ort: formData.get('kundeOrt'),
            telefon: formData.get('kundeTelefon'),
            natel: formData.get('kundeNatel')
        },
        objekt_adresse: document.getElementById('objektAdresseGleich').checked ? 
            'dito' : formData.get('objektAdresse'),
        verrechnung_adresse: document.getElementById('verrAdresseGleich').checked ? 
            'dito' : formData.get('verrAdresse'),
        arbeiten: arbeiten,
        beschreibung: formData.get('beschreibung'),
        termin_wunsch: formData.get('terminWunsch')
    };
    
    // An Server senden
    fetch('php/api.php?action=createAuftrag', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(auftragData)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            zeigeToast('Auftrag erfolgreich erstellt!', 'success');
            schliesseModal('modalNeuerAuftrag');
            document.getElementById('formNeuerAuftrag').reset();
            ladeAuftraege();
        } else {
            zeigeToast('Fehler: ' + (data.message || 'Unbekannter Fehler'), 'error');
        }
    })
    .catch(error => {
        console.error('Fehler:', error);
        zeigeToast('Verbindungsfehler beim Speichern', 'error');
    });
}

// =====================================================
// Disponieren
// =====================================================
function oeffneDisponierenModal(auftragId) {
    document.getElementById('dispAuftragId').value = auftragId;
    document.getElementById('dispTermin').valueAsDate = new Date();
    oeffneModal('modalDisponieren');
}

function speichereDisponierung(e) {
    e.preventDefault();
    
    const auftragId = document.getElementById('dispAuftragId').value;
    const mitarbeiterId = document.getElementById('dispMitarbeiter').value;
    const termin = document.getElementById('dispTermin').value;
    
    if (!mitarbeiterId || !termin) {
        zeigeToast('Bitte alle Felder ausfüllen', 'warning');
        return;
    }
    
    fetch('php/api.php?action=disponieren', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            auftrag_id: auftragId,
            mitarbeiter_id: mitarbeiterId,
            termin: termin
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            zeigeToast('Auftrag erfolgreich disponiert!', 'success');
            schliesseModal('modalDisponieren');
            ladeAuftraege();
        } else {
            zeigeToast('Fehler: ' + (data.message || 'Unbekannter Fehler'), 'error');
        }
    })
    .catch(error => {
        console.error('Fehler:', error);
        zeigeToast('Verbindungsfehler', 'error');
    });
}

// =====================================================
// Status ändern
// =====================================================
function aendereStatus(auftragId, neuerStatus) {
    if (!confirm(`Möchten Sie den Status wirklich auf "${formatiereStatus(neuerStatus)}" ändern?`)) {
        return;
    }
    
    fetch('php/api.php?action=aendereStatus', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            auftrag_id: auftragId,
            status: neuerStatus
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            zeigeToast('Status erfolgreich geändert!', 'success');
            ladeAuftraege();
        } else {
            zeigeToast('Fehler: ' + (data.message || 'Unbekannter Fehler'), 'error');
        }
    })
    .catch(error => {
        console.error('Fehler:', error);
        zeigeToast('Verbindungsfehler', 'error');
    });
}

// =====================================================
// Auftrag drucken
// =====================================================
function druckeAuftrag(auftragId) {
    window.open(`php/print.php?id=${auftragId}`, '_blank');
}

// =====================================================
// Filter und Suche
// =====================================================
function filtereAuftraege() {
    let gefilterteAuftraege = alleAuftraege;
    
    // Nach Status filtern
    if (aktuellerFilter) {
        gefilterteAuftraege = gefilterteAuftraege.filter(a => a.status === aktuellerFilter);
    }
    
    // Nach Suchwort filtern
    if (aktuellesSuchwort) {
        gefilterteAuftraege = gefilterteAuftraege.filter(a => 
            a.kunde_name.toLowerCase().includes(aktuellesSuchwort) ||
            a.beschreibung.toLowerCase().includes(aktuellesSuchwort)
        );
    }
    
    zeigeAuftraege(gefilterteAuftraege);
}

// =====================================================
// Hilfsfunktionen
// =====================================================
function oeffneModal(modalId) {
    document.getElementById(modalId).classList.add('show');
}

function schliesseModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function zeigeToast(message, type = 'info') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type}`;
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function zeigeLoader(anzeigen) {
    document.getElementById('loadingSpinner').style.display = anzeigen ? 'flex' : 'none';
}

function setzeAktuellesDatumZeit() {
    const jetzt = new Date();
    const datum = jetzt.toISOString().split('T')[0];
    const zeit = jetzt.toTimeString().slice(0, 5);
    
    document.getElementById('auftrDatum').value = datum;
    document.getElementById('auftrZeit').value = zeit;
}

function fuelleMitarbeiterDropdown() {
    const select = document.getElementById('dispMitarbeiter');
    select.innerHTML = '<option value="">-- Bitte wählen --</option>';
    
    alleMitarbeiter
        .filter(m => m.rolle !== 'administration')
        .forEach(m => {
            const option = document.createElement('option');
            option.value = m.mitarbeiter_id;
            option.textContent = m.name;
            select.appendChild(option);
        });
}

function aktualisiereStatistik() {
    document.getElementById('statsTotal').textContent = alleAuftraege.length;
}

function formatiereDatum(datum) {
    if (!datum) return '-';
    const d = new Date(datum + 'T00:00:00');
    return d.toLocaleDateString('de-CH');
}

function formatiereZeit(zeit) {
    if (!zeit) return '-';
    return zeit.slice(0, 5);
}

function formatiereDatumZeit(datetime) {
    if (!datetime) return '-';
    const d = new Date(datetime);
    return d.toLocaleString('de-CH');
}

function formatiereStatus(status) {
    const statusMap = {
        'erfasst': 'Erfasst',
        'disponiert': 'Disponiert',
        'ausgefuehrt': 'Ausgeführt',
        'freigegeben': 'Freigegeben',
        'verrechnet': 'Verrechnet'
    };
    return statusMap[status] || status;
}

function kuerzenText(text, laenge) {
    if (!text) return '';
    return text.length > laenge ? text.substring(0, laenge) + '...' : text;
}

function htmlEncode(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

function validiereAuftragFormular() {
    // Prüfe ob mindestens eine Arbeit ausgewählt ist
    const arbeiten = document.querySelectorAll('input[name="arbeiten[]"]:checked');
    if (arbeiten.length === 0) {
        zeigeToast('Bitte mindestens eine auszuführende Arbeit auswählen', 'warning');
        return false;
    }
    
    // PLZ Validierung
    const plz = document.getElementById('kundePlz').value;
    if (!/^\d{4}$/.test(plz)) {
        zeigeToast('PLZ muss 4 Ziffern haben', 'warning');
        document.getElementById('kundePlz').focus();
        return false;
    }
    
    return true;
}

function validiereNummerischesEingabefeld(input, maxLaenge) {
    input.value = input.value.replace(/\D/g, '').slice(0, maxLaenge);
}
