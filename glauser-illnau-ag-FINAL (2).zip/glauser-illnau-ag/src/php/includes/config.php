<?php
// =====================================================
// Glauser Illnau AG - Datenbank Konfiguration
// =====================================================

class Database {
    private $host = 'localhost';
    private $db_name = 'glauser_illnau_ag';
    private $username = 'root';
    private $password = '';
    private $conn = null;
    
    /**
     * Datenbankverbindung herstellen
     */
    public function getConnection() {
        if ($this->conn === null) {
            try {
                $this->conn = new PDO(
                    "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                    $this->username,
                    $this->password,
                    array(
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false
                    )
                );
            } catch(PDOException $exception) {
                error_log("Verbindungsfehler: " . $exception->getMessage());
                throw new Exception("Datenbankverbindung fehlgeschlagen");
            }
        }
        
        return $this->conn;
    }
    
    /**
     * Verbindung schließen
     */
    public function closeConnection() {
        $this->conn = null;
    }
}
?>
