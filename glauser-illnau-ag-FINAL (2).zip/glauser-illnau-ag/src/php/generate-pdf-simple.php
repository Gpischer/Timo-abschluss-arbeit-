<?php
/**
 * PDF-Generierung OHNE Python - Einfache Lösung
 * Verwendet FPDF Library (reine PHP-Lösung)
 */

require_once 'includes/config.php';

// Auftrag-ID aus GET-Parameter
$auftragId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($auftragId <= 0) {
    die("Fehler: Ungültige Auftrags-ID");
}

try {
    // Datenbankverbindung
    $database = new Database();
    $pdo = $database->getConnection();
    
    // Auftrag mit Kundendaten und Mitarbeiter abrufen
    $stmt = $pdo->prepare("
        SELECT 
            a.*,
            k.name as kunde_name,
            k.adresse as kunde_adresse,
            k.plz as kunde_plz,
            k.ort as kunde_ort,
            k.telefon as kunde_telefon,
            k.natel as kunde_natel,
            m.name as mitarbeiter_name
        FROM auftrag a
        INNER JOIN kunde k ON a.kunde_id = k.kunde_id
        LEFT JOIN mitarbeiter m ON a.mitarbeiter_id = m.mitarbeiter_id
        WHERE a.auftrag_id = ?
    ");
    
    $stmt->execute([$auftragId]);
    $auftrag = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$auftrag) {
        die("Fehler: Auftrag nicht gefunden");
    }
    
    // FPDF Library einbinden
    require_once __DIR__ . '/fpdf/fpdf.php';
    
    // PDF erstellen
    $pdf = new FPDF('P', 'mm', 'A4');
    $pdf->AddPage();
    $pdf->SetAutoPageBreak(true, 20);
    
    // Header
    $pdf->SetFillColor(13, 148, 136); // Türkis
    $pdf->Rect(0, 0, 210, 40, 'F');
    
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetFont('Arial', 'B', 24);
    $pdf->Cell(0, 15, '', 0, 1); // Abstand
    $pdf->Cell(0, 10, 'SERVICEAUFTRAG', 0, 1, 'C');
    
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 7, 'Glauser Illnau AG', 0, 1, 'C');
    
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Ln(10);
    
    // Auftragsdaten
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(100, 7, 'Auftrag Nr.: ' . $auftragId, 0, 0);
    $pdf->Cell(0, 7, 'Datum: ' . date('d.m.Y', strtotime($auftrag['datum'])), 0, 1, 'R');
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 7, 'Zeit: ' . substr($auftrag['zeit'], 0, 5) . ' Uhr', 0, 1, 'R');
    $pdf->Ln(5);
    
    // Kunde
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'KUNDE / KONTAKTPERSON:', 0, 1);
    $pdf->SetDrawColor(100, 100, 100);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 6, $auftrag['kunde_name'], 0, 1);
    $pdf->Cell(0, 6, $auftrag['kunde_adresse'], 0, 1);
    $pdf->Cell(0, 6, $auftrag['kunde_plz'] . ' ' . $auftrag['kunde_ort'], 0, 1);
    
    if ($auftrag['kunde_telefon']) {
        $pdf->Cell(0, 6, 'Telefon: ' . $auftrag['kunde_telefon'], 0, 1);
    }
    if ($auftrag['kunde_natel']) {
        $pdf->Cell(0, 6, 'Natel: ' . $auftrag['kunde_natel'], 0, 1);
    }
    $pdf->Ln(5);
    
    // Objektadresse
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'ADRESSE OBJEKT:', 0, 1);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 6, $auftrag['objekt_adresse'] ?: 'dito', 0, 1);
    $pdf->Ln(5);
    
    // Verrechnungsadresse
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'ADRESSE VERRECHNUNG:', 0, 1);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(0, 6, $auftrag['verrechnung_adresse'] ?: 'dito', 0, 1);
    $pdf->Ln(5);
    
    // Arbeiten
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'AUSZUFÜHRENDE ARBEITEN:', 0, 1);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    $arbeiten = [];
    if ($auftrag['arbeiten_reparatur']) $arbeiten[] = '[X] Reparatur';
    else $arbeiten[] = '[ ] Reparatur';
    
    if ($auftrag['arbeiten_sanitaer']) $arbeiten[] = '[X] Sanitär';
    else $arbeiten[] = '[ ] Sanitär';
    
    if ($auftrag['arbeiten_heizung']) $arbeiten[] = '[X] Heizung';
    else $arbeiten[] = '[ ] Heizung';
    
    if ($auftrag['arbeiten_garantie']) $arbeiten[] = '[X] Garantie';
    else $arbeiten[] = '[ ] Garantie';
    
    $pdf->Cell(100, 6, $arbeiten[0] . '    ' . $arbeiten[1], 0, 0);
    $pdf->Cell(0, 6, '', 0, 1);
    $pdf->Cell(100, 6, $arbeiten[2] . '    ' . $arbeiten[3], 0, 1);
    $pdf->Ln(5);
    
    // Beschreibung
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(0, 7, 'BESCHREIBUNG:', 0, 1);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(3);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(0, 6, $auftrag['beschreibung']);
    $pdf->Ln(5);
    
    // Terminwunsch
    if ($auftrag['termin_wunsch']) {
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 7, 'TERMINWUNSCH:', 0, 1);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
        $pdf->Ln(3);
        
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell(0, 6, $auftrag['termin_wunsch'], 0, 1);
        $pdf->Ln(5);
    }
    
    // Disposition (falls vorhanden)
    if ($auftrag['status'] != 'erfasst') {
        $pdf->SetFont('Arial', 'B', 11);
        $pdf->Cell(0, 7, 'DISPOSITION:', 0, 1);
        $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
        $pdf->Ln(3);
        
        $pdf->SetFont('Arial', '', 10);
        
        $status_text = [
            'erfasst' => 'Erfasst',
            'disponiert' => 'Disponiert',
            'ausgefuehrt' => 'Ausgeführt',
            'freigegeben' => 'Freigegeben',
            'verrechnet' => 'Verrechnet'
        ];
        
        $pdf->Cell(0, 6, 'Status: ' . $status_text[$auftrag['status']], 0, 1);
        
        if ($auftrag['mitarbeiter_name']) {
            $pdf->Cell(0, 6, 'Mitarbeiter: ' . $auftrag['mitarbeiter_name'], 0, 1);
        }
        
        if ($auftrag['termin']) {
            $pdf->Cell(0, 6, 'Termin: ' . date('d.m.Y', strtotime($auftrag['termin'])), 0, 1);
        }
    }
    
    // Footer
    $pdf->SetY(-20);
    $pdf->SetDrawColor(200, 200, 200);
    $pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
    $pdf->Ln(2);
    
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetTextColor(100, 100, 100);
    $pdf->Cell(0, 5, 'Glauser Illnau AG | Sanitärunternehmen', 0, 1, 'C');
    $pdf->Cell(0, 5, 'Erstellt am ' . date('d.m.Y H:i') . ' Uhr', 0, 1, 'C');
    
    // PDF ausgeben
    $pdf->Output('D', 'Serviceauftrag_' . $auftragId . '.pdf');
    
} catch (Exception $e) {
    error_log("Fehler in generate-pdf.php: " . $e->getMessage());
    die("Ein Fehler ist aufgetreten: " . $e->getMessage());
}
