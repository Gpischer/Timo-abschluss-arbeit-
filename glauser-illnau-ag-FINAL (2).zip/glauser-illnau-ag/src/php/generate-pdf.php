<?php
/**
 * PDF-Generierung - Weiterleit auf print.php
 * Der Browser kann dann "Als PDF speichern" wählen
 */

$auftragId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($auftragId <= 0) {
    die("Fehler: Ungültige Auftrags-ID");
}

// Einfach auf print.php weiterleiten
// Der Nutzer kann dann im Browser-Druckdialog "Als PDF speichern" wählen
header("Location: print.php?id=" . $auftragId);
exit;
