<?php
// =====================================================
// Glauser Illnau AG - REST API
// =====================================================

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'includes/config.php';

// Fehlerbehandlung
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    throw new ErrorException($errstr, 0, $errno, $errfile, $errline);
});

// Request verarbeiten
try {
    $database = new Database();
    $db = $database->getConnection();
    
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'getAuftraege':
            getAuftraege($db);
            break;
            
        case 'getAuftrag':
            getAuftrag($db);
            break;
            
        case 'createAuftrag':
            createAuftrag($db);
            break;
            
        case 'disponieren':
            disponieren($db);
            break;
            
        case 'aendereStatus':
            aendereStatus($db);
            break;
            
        case 'getMitarbeiter':
            getMitarbeiter($db);
            break;
            
        default:
            throw new Exception('Ungültige Aktion');
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}

// =====================================================
// API Funktionen
// =====================================================

/**
 * Alle Aufträge abrufen
 */
function getAuftraege($db) {
    $query = "
        SELECT 
            a.*,
            k.name AS kunde_name,
            k.adresse AS kunde_adresse,
            k.plz AS kunde_plz,
            k.ort AS kunde_ort,
            k.telefon AS kunde_telefon,
            k.natel AS kunde_natel,
            m.name AS mitarbeiter_name
        FROM auftrag a
        INNER JOIN kunde k ON a.kunde_id = k.kunde_id
        LEFT JOIN mitarbeiter m ON a.mitarbeiter_id = m.mitarbeiter_id
        ORDER BY 
            CASE a.status
                WHEN 'erfasst' THEN 1
                WHEN 'disponiert' THEN 2
                WHEN 'ausgefuehrt' THEN 3
                WHEN 'freigegeben' THEN 4
                WHEN 'verrechnet' THEN 5
            END,
            a.datum DESC,
            a.zeit DESC
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $auftraege = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $auftraege
    ]);
}

/**
 * Einzelnen Auftrag abrufen
 */
function getAuftrag($db) {
    $id = $_GET['id'] ?? 0;
    
    $query = "
        SELECT 
            a.*,
            k.name AS kunde_name,
            k.adresse AS kunde_adresse,
            k.plz AS kunde_plz,
            k.ort AS kunde_ort,
            k.telefon AS kunde_telefon,
            k.natel AS kunde_natel,
            m.name AS mitarbeiter_name
        FROM auftrag a
        INNER JOIN kunde k ON a.kunde_id = k.kunde_id
        LEFT JOIN mitarbeiter m ON a.mitarbeiter_id = m.mitarbeiter_id
        WHERE a.auftrag_id = :id
    ";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    $auftrag = $stmt->fetch();
    
    if ($auftrag) {
        echo json_encode([
            'success' => true,
            'data' => $auftrag
        ]);
    } else {
        throw new Exception('Auftrag nicht gefunden');
    }
}

/**
 * Neuen Auftrag erstellen
 */
function createAuftrag($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input) {
        throw new Exception('Ungültige Eingabedaten');
    }
    
    // Validierung
    if (empty($input['datum']) || empty($input['zeit']) || empty($input['beschreibung'])) {
        throw new Exception('Pflichtfelder fehlen');
    }
    
    if (empty($input['kunde']['name']) || empty($input['kunde']['plz'])) {
        throw new Exception('Kundendaten unvollständig');
    }
    
    $db->beginTransaction();
    
    try {
        // Kunde erstellen oder finden
        $kunde_id = erstelleOderFindeKunde($db, $input['kunde']);
        
        // Auftrag erstellen
        $query = "
            INSERT INTO auftrag (
                datum, zeit, kunde_id, objekt_adresse, verrechnung_adresse,
                arbeiten_reparatur, arbeiten_sanitaer, arbeiten_heizung, arbeiten_garantie,
                beschreibung, termin_wunsch, status
            ) VALUES (
                :datum, :zeit, :kunde_id, :objekt_adresse, :verrechnung_adresse,
                :reparatur, :sanitaer, :heizung, :garantie,
                :beschreibung, :termin_wunsch, 'erfasst'
            )
        ";
        
        $stmt = $db->prepare($query);
        $stmt->execute([
            ':datum' => $input['datum'],
            ':zeit' => $input['zeit'],
            ':kunde_id' => $kunde_id,
            ':objekt_adresse' => $input['objekt_adresse'] ?? null,
            ':verrechnung_adresse' => $input['verrechnung_adresse'] ?? null,
            ':reparatur' => in_array('reparatur', $input['arbeiten'] ?? []),
            ':sanitaer' => in_array('sanitaer', $input['arbeiten'] ?? []),
            ':heizung' => in_array('heizung', $input['arbeiten'] ?? []),
            ':garantie' => in_array('garantie', $input['arbeiten'] ?? []),
            ':beschreibung' => $input['beschreibung'],
            ':termin_wunsch' => $input['termin_wunsch'] ?? null
        ]);
        
        $auftrag_id = $db->lastInsertId();
        
        $db->commit();
        
        echo json_encode([
            'success' => true,
            'message' => 'Auftrag erfolgreich erstellt',
            'auftrag_id' => $auftrag_id
        ]);
        
    } catch (Exception $e) {
        $db->rollBack();
        throw $e;
    }
}

/**
 * Kunde erstellen oder existierenden finden
 */
function erstelleOderFindeKunde($db, $kundeData) {
    // Prüfen ob Kunde bereits existiert
    $query = "
        SELECT kunde_id 
        FROM kunde 
        WHERE name = :name 
        AND plz = :plz 
        AND ort = :ort
        LIMIT 1
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':name' => $kundeData['name'],
        ':plz' => $kundeData['plz'],
        ':ort' => $kundeData['ort']
    ]);
    
    $existing = $stmt->fetch();
    
    if ($existing) {
        return $existing['kunde_id'];
    }
    
    // Neuen Kunden erstellen
    $query = "
        INSERT INTO kunde (name, adresse, plz, ort, telefon, natel)
        VALUES (:name, :adresse, :plz, :ort, :telefon, :natel)
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':name' => $kundeData['name'],
        ':adresse' => $kundeData['adresse'],
        ':plz' => $kundeData['plz'],
        ':ort' => $kundeData['ort'],
        ':telefon' => $kundeData['telefon'] ?? null,
        ':natel' => $kundeData['natel'] ?? null
    ]);
    
    return $db->lastInsertId();
}

/**
 * Auftrag disponieren
 */
function disponieren($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || empty($input['auftrag_id']) || empty($input['mitarbeiter_id']) || empty($input['termin'])) {
        throw new Exception('Unvollständige Daten');
    }
    
    $query = "
        UPDATE auftrag
        SET status = 'disponiert',
            mitarbeiter_id = :mitarbeiter_id,
            termin = :termin
        WHERE auftrag_id = :auftrag_id
        AND status = 'erfasst'
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':auftrag_id' => $input['auftrag_id'],
        ':mitarbeiter_id' => $input['mitarbeiter_id'],
        ':termin' => $input['termin']
    ]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Auftrag erfolgreich disponiert'
        ]);
    } else {
        throw new Exception('Auftrag konnte nicht disponiert werden (bereits disponiert oder nicht gefunden)');
    }
}

/**
 * Status ändern
 */
function aendereStatus($db) {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || empty($input['auftrag_id']) || empty($input['status'])) {
        throw new Exception('Unvollständige Daten');
    }
    
    $erlaubteStatus = ['erfasst', 'disponiert', 'ausgefuehrt', 'freigegeben', 'verrechnet'];
    if (!in_array($input['status'], $erlaubteStatus)) {
        throw new Exception('Ungültiger Status');
    }
    
    // Status-Übergangs-Validierung
    $query = "SELECT status FROM auftrag WHERE auftrag_id = :id";
    $stmt = $db->prepare($query);
    $stmt->execute([':id' => $input['auftrag_id']]);
    $auftrag = $stmt->fetch();
    
    if (!$auftrag) {
        throw new Exception('Auftrag nicht gefunden');
    }
    
    $aktuellerStatus = $auftrag['status'];
    $neuerStatus = $input['status'];
    
    // Erlaubte Übergänge prüfen
    $erlaubteUebergaenge = [
        'erfasst' => ['disponiert'],
        'disponiert' => ['ausgefuehrt'],
        'ausgefuehrt' => ['freigegeben'],
        'freigegeben' => ['verrechnet']
    ];
    
    if (!isset($erlaubteUebergaenge[$aktuellerStatus]) || 
        !in_array($neuerStatus, $erlaubteUebergaenge[$aktuellerStatus])) {
        throw new Exception("Ungültiger Status-Übergang von '$aktuellerStatus' zu '$neuerStatus'");
    }
    
    // Status aktualisieren
    $query = "UPDATE auftrag SET status = :status WHERE auftrag_id = :id";
    $stmt = $db->prepare($query);
    $stmt->execute([
        ':status' => $neuerStatus,
        ':id' => $input['auftrag_id']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Status erfolgreich geändert'
    ]);
}

/**
 * Mitarbeiter abrufen
 */
function getMitarbeiter($db) {
    $query = "
        SELECT mitarbeiter_id, name, rolle
        FROM mitarbeiter
        ORDER BY name
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $mitarbeiter = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $mitarbeiter
    ]);
}
?>
