<?php
// =====================================================
// Glauser Illnau AG - Serviceauftrag Drucken
// =====================================================

require_once 'includes/config.php';

$auftrag_id = $_GET['id'] ?? 0;

if (!$auftrag_id) {
    die('Keine Auftrags-ID angegeben');
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $query = "
        SELECT 
            a.*,
            k.name AS kunde_name,
            k.adresse AS kunde_adresse,
            k.plz AS kunde_plz,
            k.ort AS kunde_ort,
            k.telefon AS kunde_telefon,
            k.natel AS kunde_natel,
            m.name AS mitarbeiter_name
        FROM auftrag a
        INNER JOIN kunde k ON a.kunde_id = k.kunde_id
        LEFT JOIN mitarbeiter m ON a.mitarbeiter_id = m.mitarbeiter_id
        WHERE a.auftrag_id = :id
    ";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $auftrag_id, PDO::PARAM_INT);
    $stmt->execute();
    $auftrag = $stmt->fetch();
    
    if (!$auftrag) {
        die('Auftrag nicht gefunden');
    }
    
} catch (Exception $e) {
    die('Fehler beim Laden des Auftrags: ' . $e->getMessage());
}

// Hilfsfunktionen
function formatiereDatum($datum) {
    if (!$datum) return '-';
    $d = new DateTime($datum);
    return $d->format('d.m.Y');
}

function formatiereZeit($zeit) {
    if (!$zeit) return '-';
    return substr($zeit, 0, 5);
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Serviceauftrag Nr. <?= htmlspecialchars($auftrag['auftrag_id']) ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            font-size: 10pt;
            line-height: 1.3;
            padding: 12mm;
            max-width: 210mm;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            border-bottom: 3px solid #0d9488;
            padding-bottom: 8px;
            margin-bottom: 12px;
        }
        
        .header h1 {
            font-size: 20pt;
            color: #0d9488;
            margin-bottom: 3px;
        }
        
        .header .subtitle {
            font-size: 11pt;
            color: #666;
        }
        
        .meta-info {
            display: table;
            width: 100%;
            margin-bottom: 12px;
        }
        
        .meta-row {
            display: table-row;
        }
        
        .meta-label {
            display: table-cell;
            font-weight: bold;
            width: 100px;
            padding: 2px 10px 2px 0;
            font-size: 9pt;
        }
        
        .meta-value {
            display: table-cell;
            padding: 2px 0;
            font-size: 9pt;
        }
        
        .section {
            margin-bottom: 10px;
            page-break-inside: avoid;
        }
        
        .section-title {
            font-size: 11pt;
            font-weight: bold;
            color: #0d9488;
            border-bottom: 1px solid #e0e0e0;
            padding-bottom: 3px;
            margin-bottom: 6px;
        }
        
        .checkbox-line {
            margin: 4px 0;
            display: inline-block;
            margin-right: 20px;
        }
        
        .checkbox {
            display: inline-block;
            width: 14px;
            height: 14px;
            border: 2px solid #0d9488;
            border-radius: 2px;
            margin-right: 6px;
            position: relative;
            vertical-align: middle;
        }
        
        .checkbox.checked::before {
            content: '✓';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 12px;
            font-weight: bold;
            color: #0d9488;
            line-height: 1;
        }
        
        .description-box {
            border: 1px solid #ccc;
            padding: 6px;
            min-height: 50px;
            background: #f9f9f9;
            white-space: pre-wrap;
            font-size: 9pt;
        }
        
        .footer {
            margin-top: 20px;
            padding: 12px 0;
            border-top: 2px solid #0d9488;
            background: linear-gradient(to bottom, #f0fdfa, #ffffff);
            text-align: center;
        }
        
        .footer-company {
            font-size: 10pt;
            font-weight: bold;
            color: #0d9488;
            margin-bottom: 4px;
        }
        
        .footer-type {
            font-size: 9pt;
            color: #0f766e;
            font-weight: 500;
            margin-bottom: 6px;
        }
        
        .footer-date {
            font-size: 8pt;
            color: #64748b;
            font-style: italic;
        }
        
        .content-wrapper {
            /* Kein margin-bottom auf Webseite */
        }
        
        @media print {
            @page {
                size: A4;
                margin: 10mm;
            }
            
            body {
                padding: 0;
                font-size: 9pt;
            }
            
            .content-wrapper {
                margin-bottom: 70px;  /* Nur beim Drucken! */
            }
            
            .footer {
                position: fixed;      /* Nur beim Drucken fixed! */
                bottom: 0;
                left: 0;
                right: 0;
                padding: 8px 0;
                border-top: 2px solid #0d9488;
                background: #f8fafc;
            }
            
            .no-print {
                display: none !important;
            }
            
            .section {
                page-break-inside: avoid;
            }
            
            .header {
                margin-bottom: 8px;
                padding-bottom: 6px;
            }
            
            .header h1 {
                font-size: 18pt;
            }
            
            .section-title {
                font-size: 10pt;
                margin-bottom: 4px;
            }
            
            .description-box {
                min-height: 40px;
                padding: 4px;
            }
            
            .footer {
                margin-top: 10px;
                padding-top: 8px;
            }
        }
        
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background: #2c5f8d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14pt;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        .print-button:hover {
            background: #1a3d5c;
        }
    </style>
</head>
<body>
    <button class="print-button no-print" onclick="window.print()">🖨️ Drucken</button>
    
    <div class="content-wrapper">
    <div class="header">
        <h1>SERVICEAUFTRAG</h1>
        <p class="subtitle">Glauser Illnau AG</p>
    </div>
    
    <div class="meta-info">
        <div class="meta-row">
            <div class="meta-label">Datum:</div>
            <div class="meta-value"><?= formatiereDatum($auftrag['datum']) ?></div>
        </div>
        <div class="meta-row">
            <div class="meta-label">Zeit:</div>
            <div class="meta-value"><?= formatiereZeit($auftrag['zeit']) ?></div>
        </div>
        <div class="meta-row">
            <div class="meta-label">Auftrag Nr.:</div>
            <div class="meta-value"><?= htmlspecialchars($auftrag['auftrag_id']) ?></div>
        </div>
    </div>
    
    <div class="section">
        <h2 class="section-title">Kunde / Kontaktperson:</h2>
        <div class="meta-info">
            <div class="meta-row">
                <div class="meta-label">Name:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['kunde_name']) ?></div>
            </div>
            <div class="meta-row">
                <div class="meta-label">Adresse:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['kunde_adresse']) ?></div>
            </div>
            <div class="meta-row">
                <div class="meta-label">PLZ / Ort:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['kunde_plz']) ?> <?= htmlspecialchars($auftrag['kunde_ort']) ?></div>
            </div>
            <?php if ($auftrag['kunde_telefon']): ?>
            <div class="meta-row">
                <div class="meta-label">Telefon:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['kunde_telefon']) ?></div>
            </div>
            <?php endif; ?>
            <?php if ($auftrag['kunde_natel']): ?>
            <div class="meta-row">
                <div class="meta-label">Natel:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['kunde_natel']) ?></div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="section">
        <h2 class="section-title">Adressen:</h2>
        <div class="meta-info">
            <div class="meta-row">
                <div class="meta-label">Objekt:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['objekt_adresse'] ?: 'dito') ?></div>
            </div>
            <div class="meta-row">
                <div class="meta-label">Verrechnung:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['verrechnung_adresse'] ?: 'dito') ?></div>
            </div>
        </div>
    </div>
    
    <div class="section">
        <h2 class="section-title">Auszuführende Arbeiten:</h2>
        <div class="checkbox-line">
            <span class="checkbox <?= $auftrag['arbeiten_reparatur'] ? 'checked' : '' ?>"></span>
            Reparatur
        </div>
        <div class="checkbox-line">
            <span class="checkbox <?= $auftrag['arbeiten_sanitaer'] ? 'checked' : '' ?>"></span>
            Sanitär
        </div>
        <div class="checkbox-line">
            <span class="checkbox <?= $auftrag['arbeiten_heizung'] ? 'checked' : '' ?>"></span>
            Heizung
        </div>
        <div class="checkbox-line">
            <span class="checkbox <?= $auftrag['arbeiten_garantie'] ? 'checked' : '' ?>"></span>
            Garantie
        </div>
    </div>
    
    <div class="section">
        <h2 class="section-title">Beschreibung:</h2>
        <div class="description-box"><?= htmlspecialchars($auftrag['beschreibung']) ?></div>
    </div>
    
    <div class="section">
        <h2 class="section-title">Weitere Informationen:</h2>
        <div class="meta-info">
            <div class="meta-row">
                <div class="meta-label">Terminwunsch:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['termin_wunsch'] ?: '-') ?></div>
            </div>
            <?php if ($auftrag['mitarbeiter_name']): ?>
            <div class="meta-row">
                <div class="meta-label">Mitarbeiter:</div>
                <div class="meta-value"><?= htmlspecialchars($auftrag['mitarbeiter_name']) ?></div>
            </div>
            <?php if ($auftrag['termin']): ?>
            <div class="meta-row">
                <div class="meta-label">Termin:</div>
                <div class="meta-value"><?= formatiereDatum($auftrag['termin']) ?></div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
            <div class="meta-row">
                <div class="meta-label">Status:</div>
                <div class="meta-value">
                    <?php
                    $status_text = [
                        'erfasst' => 'Erfasst',
                        'disponiert' => 'Disponiert',
                        'ausgefuehrt' => 'Ausgeführt',
                        'freigegeben' => 'Freigegeben',
                        'verrechnet' => 'Verrechnet'
                    ];
                    echo $status_text[$auftrag['status']] ?? $auftrag['status'];
                    ?>
                </div>
            </div>
        </div>
    </div>
    </div>
    
    <div class="no-print" style="margin: 30px 0; text-align: center; padding: 20px; background: #f0f9ff; border: 2px solid #0d9488; border-radius: 12px;">
        <h3 style="color: #0d9488; margin: 0 0 10px 0;">📄 PDF erstellen</h3>
        <p style="margin: 0 0 15px 0; color: #334155;">Nutze die Drucken-Funktion deines Browsers:</p>
        <button onclick="window.print()" style="padding: 12px 28px; background: linear-gradient(135deg, #0d9488, #14b8a6); color: white; border: none; border-radius: 10px; font-size: 14px; font-weight: 600; cursor: pointer; box-shadow: 0 4px 6px rgba(0,0,0,0.1); margin-right: 10px;">
            🖨️ Drucken
        </button>
        <div style="margin-top: 10px; font-size: 13px; color: #64748b;">
            💡 <strong>Tipp:</strong> Im Druckdialog "Als PDF speichern" oder "Microsoft Print to PDF" wählen
        </div>
    </div>
    
    <div class="footer">
        <div class="footer-company">Glauser Illnau AG</div>
        <div class="footer-type">Sanitärunternehmen</div>
        <div class="footer-date">Erstellt am <?= date('d.m.Y') ?> um <?= date('H:i') ?> Uhr</div>
    </div>
</body>
</html>
