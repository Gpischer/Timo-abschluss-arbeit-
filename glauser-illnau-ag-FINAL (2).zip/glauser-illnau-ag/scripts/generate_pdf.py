#!/usr/bin/env python3
"""
PDF-Generierung für Glauser Illnau AG Serviceaufträge
Erstellt professionelle PDF-Dokumente mit reportlab
"""

import sys
import json
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from datetime import datetime

def format_date(date_str):
    """Formatiert Datum von YYYY-MM-DD zu DD.MM.YYYY"""
    if not date_str:
        return ""
    try:
        date_obj = datetime.strptime(date_str, "%Y-%m-%d")
        return date_obj.strftime("%d.%m.%Y")
    except:
        return date_str

def format_time(time_str):
    """Formatiert Zeit von HH:MM:SS zu HH:MM"""
    if not time_str:
        return ""
    return time_str[:5]

def draw_checkbox(c, x, y, checked=False):
    """Zeichnet eine Checkbox mit Häkchen in der Mitte"""
    box_size = 4.5*mm
    
    # Box zeichnen
    c.setStrokeColor(HexColor('#0d9488'))
    c.setLineWidth(1.5)
    c.rect(x, y, box_size, box_size, stroke=1, fill=0)
    
    if checked:
        # Häkchen zeichnen - perfekt zentriert
        c.setStrokeColor(HexColor('#0d9488'))
        c.setLineWidth(2)
        
        # Häkchen als zwei Linien (✓)
        # Erster Strich (kurz, schräg nach unten)
        c.line(x + 0.8*mm, y + 2.3*mm, x + 1.8*mm, y + 1.2*mm)
        # Zweiter Strich (lang, schräg nach oben)
        c.line(x + 1.8*mm, y + 1.2*mm, x + 3.7*mm, y + 3.5*mm)


def generate_pdf(data, output_path):
    """Generiert PDF-Dokument"""
    
    # Canvas erstellen
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4
    
    # Farben
    primary_color = HexColor('#0d9488')
    text_color = HexColor('#0f172a')
    gray_color = HexColor('#64748b')
    
    # Positionen
    margin_left = 25*mm
    margin_right = width - 25*mm
    y_pos = height - 25*mm
    
    # === HEADER ===
    c.setFillColor(primary_color)
    c.setFont("Helvetica-Bold", 24)
    c.drawString(margin_left, y_pos, "SERVICEAUFTRAG")
    y_pos -= 8*mm
    
    c.setFillColor(text_color)
    c.setFont("Helvetica", 12)
    c.drawString(margin_left, y_pos, "Glauser Illnau AG")
    y_pos -= 5*mm
    
    c.setFillColor(gray_color)
    c.setFont("Helvetica", 9)
    c.drawString(margin_left, y_pos, "Sanitärunternehmen")
    y_pos -= 12*mm
    
    # Linie
    c.setStrokeColor(primary_color)
    c.setLineWidth(2)
    c.line(margin_left, y_pos, margin_right, y_pos)
    y_pos -= 10*mm
    
    # === AUFTRAGSDATEN ===
    c.setFillColor(text_color)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(margin_left, y_pos, f"Auftrag Nr.: {data['auftrag_id']}")
    
    c.drawRightString(margin_right, y_pos, f"Datum: {format_date(data['datum'])}")
    y_pos -= 5*mm
    
    c.setFont("Helvetica", 10)
    c.drawRightString(margin_right, y_pos, f"Zeit: {format_time(data['zeit'])} Uhr")
    y_pos -= 10*mm
    
    # === KUNDE ===
    c.setFont("Helvetica-Bold", 11)
    c.drawString(margin_left, y_pos, "KUNDE / KONTAKTPERSON:")
    y_pos -= 1*mm
    
    c.setStrokeColor(gray_color)
    c.setLineWidth(0.5)
    c.line(margin_left, y_pos, margin_right, y_pos)
    y_pos -= 6*mm
    
    c.setFont("Helvetica", 10)
    c.drawString(margin_left, y_pos, data['kunde_name'] or "")
    y_pos -= 5*mm
    
    c.drawString(margin_left, y_pos, data['kunde_adresse'] or "")
    y_pos -= 5*mm
    
    c.drawString(margin_left, y_pos, f"{data['kunde_plz']} {data['kunde_ort']}")
    y_pos -= 7*mm
    
    if data['kunde_telefon']:
        c.drawString(margin_left, y_pos, f"Telefon: {data['kunde_telefon']}")
        y_pos -= 5*mm
    
    if data['kunde_natel']:
        c.drawString(margin_left, y_pos, f"Natel: {data['kunde_natel']}")
        y_pos -= 5*mm
    
    y_pos -= 5*mm
    
    # === OBJEKTADRESSE ===
    c.setFont("Helvetica-Bold", 11)
    c.drawString(margin_left, y_pos, "ADRESSE OBJEKT:")
    y_pos -= 1*mm
    
    c.setLineWidth(0.5)
    c.line(margin_left, y_pos, margin_right, y_pos)
    y_pos -= 6*mm
    
    c.setFont("Helvetica", 10)
    obj_addr = data.get('objekt_adresse') or "dito"
    c.drawString(margin_left, y_pos, obj_addr)
    y_pos -= 10*mm
    
    # === VERRECHNUNGSADRESSE ===
    c.setFont("Helvetica-Bold", 11)
    c.drawString(margin_left, y_pos, "ADRESSE VERRECHNUNG:")
    y_pos -= 1*mm
    
    c.setLineWidth(0.5)
    c.line(margin_left, y_pos, margin_right, y_pos)
    y_pos -= 6*mm
    
    c.setFont("Helvetica", 10)
    verr_addr = data.get('verrechnung_adresse') or "dito"
    c.drawString(margin_left, y_pos, verr_addr)
    y_pos -= 10*mm
    
    # === ARBEITEN ===
    c.setFont("Helvetica-Bold", 11)
    c.drawString(margin_left, y_pos, "AUSZUFÜHRENDE ARBEITEN:")
    y_pos -= 1*mm
    
    c.setLineWidth(0.5)
    c.line(margin_left, y_pos, margin_right, y_pos)
    y_pos -= 8*mm
    
    c.setFont("Helvetica", 10)
    
    # Checkboxen in 2 Spalten
    checkbox_y = y_pos
    
    # Spalte 1
    draw_checkbox(c, margin_left, checkbox_y, data.get('arbeiten_reparatur', False))
    c.drawString(margin_left + 6*mm, checkbox_y, "Reparatur")
    
    draw_checkbox(c, margin_left, checkbox_y - 6*mm, data.get('arbeiten_sanitaer', False))
    c.drawString(margin_left + 6*mm, checkbox_y - 6*mm, "Sanitär")
    
    # Spalte 2
    col2_x = margin_left + 50*mm
    draw_checkbox(c, col2_x, checkbox_y, data.get('arbeiten_heizung', False))
    c.drawString(col2_x + 6*mm, checkbox_y, "Heizung")
    
    draw_checkbox(c, col2_x, checkbox_y - 6*mm, data.get('arbeiten_garantie', False))
    c.drawString(col2_x + 6*mm, checkbox_y - 6*mm, "Garantie")
    
    y_pos -= 15*mm
    
    # === BESCHREIBUNG ===
    c.setFont("Helvetica-Bold", 11)
    c.drawString(margin_left, y_pos, "BESCHREIBUNG:")
    y_pos -= 1*mm
    
    c.setLineWidth(0.5)
    c.line(margin_left, y_pos, margin_right, y_pos)
    y_pos -= 6*mm
    
    c.setFont("Helvetica", 10)
    
    # Textumbruch für Beschreibung
    beschreibung = data.get('beschreibung', '')
    max_width = margin_right - margin_left
    text_obj = c.beginText(margin_left, y_pos)
    text_obj.setFont("Helvetica", 10)
    
    # Einfacher Textumbruch
    words = beschreibung.split()
    line = ""
    for word in words:
        test_line = line + word + " "
        if c.stringWidth(test_line, "Helvetica", 10) < max_width:
            line = test_line
        else:
            text_obj.textLine(line.strip())
            line = word + " "
    if line:
        text_obj.textLine(line.strip())
    
    c.drawText(text_obj)
    
    # Berechne wie viele Zeilen verwendet wurden
    line_count = len([l for l in beschreibung.split() if l])
    lines_used = max(1, (line_count * c.stringWidth("x ", "Helvetica", 10)) // max_width + 1)
    y_pos -= (lines_used * 5*mm + 5*mm)
    
    # === TERMINWUNSCH ===
    if data.get('termin_wunsch'):
        c.setFont("Helvetica-Bold", 11)
        c.drawString(margin_left, y_pos, "TERMINWUNSCH:")
        y_pos -= 1*mm
        
        c.setLineWidth(0.5)
        c.line(margin_left, y_pos, margin_right, y_pos)
        y_pos -= 6*mm
        
        c.setFont("Helvetica", 10)
        c.drawString(margin_left, y_pos, data['termin_wunsch'])
        y_pos -= 10*mm
    
    # === STATUS (falls disponiert/zugewiesen) ===
    if data.get('status') != 'erfasst':
        y_pos -= 5*mm
        c.setFont("Helvetica-Bold", 11)
        c.drawString(margin_left, y_pos, "DISPOSITION:")
        y_pos -= 1*mm
        
        c.setLineWidth(0.5)
        c.line(margin_left, y_pos, margin_right, y_pos)
        y_pos -= 6*mm
        
        c.setFont("Helvetica", 10)
        
        status_text = {
            'erfasst': 'Erfasst',
            'disponiert': 'Disponiert',
            'ausgefuehrt': 'Ausgeführt',
            'freigegeben': 'Freigegeben',
            'verrechnet': 'Verrechnet'
        }.get(data['status'], data['status'])
        
        c.drawString(margin_left, y_pos, f"Status: {status_text}")
        y_pos -= 5*mm
        
        if data.get('mitarbeiter_name'):
            c.drawString(margin_left, y_pos, f"Mitarbeiter: {data['mitarbeiter_name']}")
            y_pos -= 5*mm
        
        if data.get('termin'):
            c.drawString(margin_left, y_pos, f"Termin: {format_date(data['termin'])}")
            y_pos -= 5*mm
    
    # === FOOTER ===
    footer_y = 20*mm
    c.setStrokeColor(gray_color)
    c.setLineWidth(0.5)
    c.line(margin_left, footer_y + 5*mm, margin_right, footer_y + 5*mm)
    
    c.setFillColor(gray_color)
    c.setFont("Helvetica", 8)
    c.drawCentredString(width/2, footer_y, "Glauser Illnau AG | Sanitärunternehmen")
    c.drawCentredString(width/2, footer_y - 3*mm, f"Erstellt am {datetime.now().strftime('%d.%m.%Y %H:%M')} Uhr")
    
    # PDF speichern
    c.save()
    
    return True

def main():
    if len(sys.argv) != 3:
        print("Usage: generate_pdf.py <input_json> <output_pdf>")
        sys.exit(1)
    
    input_json = sys.argv[1]
    output_pdf = sys.argv[2]
    
    try:
        # JSON-Daten laden
        with open(input_json, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # PDF generieren
        generate_pdf(data, output_pdf)
        
        print(f"PDF erfolgreich erstellt: {output_pdf}")
        sys.exit(0)
        
    except Exception as e:
        print(f"Fehler: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
