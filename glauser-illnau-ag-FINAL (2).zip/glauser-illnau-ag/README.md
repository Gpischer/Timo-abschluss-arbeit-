# Glauser Illnau AG - Auftragsverwaltung

![Status](https://img.shields.io/badge/Status-Fertig-success)
![PHP](https://img.shields.io/badge/PHP-7.4+-blue)
![MySQL](https://img.shields.io/badge/MySQL-8.0-orange)

Digitale Auftragsverwaltung für Sanitärunternehmen - Projektarbeit Applikationslehre 2. Jahr

---

## 📋 Projektübersicht

Webbasierte Anwendung zur Verwaltung von Serviceaufträgen für die Firma Glauser Illnau AG (Sanitärunternehmen). Das System bildet den kompletten 6-stufigen internen Ablauf digital ab.

### ✨ Hauptfunktionen

- ✅ **Auftrag erfassen** - Digitale Erfassung mit automatischer Kundenverwaltung
- ✅ **Auftrag disponieren** - Mitarbeiter zuweisen und Termine planen
- ✅ **Status-Workflow** - 5 Status mit sequenzieller Validierung
- ✅ **Drucken & PDF** - Professionelle Ausgabe als HTML oder PDF
- ✅ **Filtern & Suchen** - Nach Status filtern und Live-Suche
- ✅ **Überwachen** - Bereichsleiter kann Fortschritt kontrollieren

### 🎯 Workflow

```
Erfasst → Disponiert → Ausgeführt → Freigegeben → Verrechnet
```

---

## 🛠️ Technologie-Stack

| Bereich | Technologie |
|---------|-------------|
| **Frontend** | HTML5, CSS3, JavaScript ES6+ |
| **Backend** | PHP 7.4+ |
| **Datenbank** | MySQL 8.0 |
| **Server** | Apache |
| **PDF-Export** | Python 3 + reportlab |
| **Pattern** | MVC-Architektur |

---

## 📦 Installation

### Voraussetzungen

- XAMPP oder WAMP (PHP 7.4+, MySQL 8.0+, Apache)
- Für PDF-Export: Python 3 + reportlab (optional)

### Schritt 1: Repository klonen

```bash
git clone https://github.com/DEIN-USERNAME/glauser-illnau-ag.git
cd glauser-illnau-ag
```

### Schritt 2: Datenbank einrichten

1. XAMPP starten (Apache + MySQL)
2. phpMyAdmin öffnen: `http://localhost/phpmyadmin`
3. SQL-Tab öffnen
4. Datei `database/schema.sql` mit Editor öffnen
5. Kompletten Inhalt kopieren und in phpMyAdmin einfügen
6. "Ausführen" klicken

✅ Datenbank `glauser_illnau_ag` wurde erstellt mit Testdaten

### Schritt 3: Dateien kopieren

Kopiere den Inhalt von `src/` nach `C:/xampp/htdocs/glauser-illnau-ag/`:

```
src/index.html       → htdocs/glauser-illnau-ag/index.html
src/css/             → htdocs/glauser-illnau-ag/css/
src/js/              → htdocs/glauser-illnau-ag/js/
src/php/             → htdocs/glauser-illnau-ag/php/
```

### Schritt 4: Konfiguration (optional)

Falls deine MySQL-Zugangsdaten anders sind:

Öffne `php/includes/config.php` und passe an:

```php
private $host = "localhost";
private $db_name = "glauser_illnau_ag";
private $username = "root";
private $password = "";  // Dein MySQL-Passwort
```

### Schritt 5: Anwendung starten

1. Browser öffnen
2. URL: `http://localhost/glauser-illnau-ag/`
3. ✅ Fertig!

---

## 📚 Dokumentation

Das Projekt enthält **umfangreiche Dokumentation**:

| Dokument | Inhalt |
|----------|--------|
| `docs/Projektdokumentation.md` | Anforderungen, Architektur, Technologien |
| `docs/Workflow-Dokumentation.md` | 6-Schritte Ablauf detailliert erklärt |
| `docs/UML-Diagramme.md` | Use Case, Klassen, ERD, Activity, Sequence |
| `docs/ERM-Detailliert.md` | Verfeinertes Datenmodell mit Attributen |
| `docs/UI-Mockups.md` | Wireframes und Design-Patterns |
| **`docs/erm-diagram.txt`** | **ERM als ASCII-Diagramm** ⭐ |
| **`docs/ui-skizze.txt`** | **UI-Skizze als ASCII-Art** ⭐ |
| `docs/PDF-Installation.md` | Setup für PDF-Export |
| `docs/Benutzerhandbuch.md` | Anleitung für Endbenutzer |
| `tests/Testprotokoll.md` | 25+ Testfälle |

---

## 🏗️ Projekt-Struktur

```
glauser-illnau-ag/
├── docs/                        # Dokumentation (10 Dateien)
│   ├── erm-diagram.txt         # ⭐ ERM-Diagramm
│   ├── ui-skizze.txt           # ⭐ UI-Skizze
│   ├── Projektdokumentation.md
│   ├── Workflow-Dokumentation.md
│   ├── UML-Diagramme.md
│   ├── ERM-Detailliert.md
│   ├── UI-Mockups.md
│   ├── PDF-Installation.md
│   └── Benutzerhandbuch.md
│
├── database/                    # Datenbank
│   └── schema.sql              # SQL-Code (300 Zeilen)
│
├── src/                         # Quellcode (2900 Zeilen)
│   ├── index.html
│   ├── css/style.css
│   ├── js/app.js
│   └── php/
│
├── scripts/                     # Python für PDF
│   └── generate_pdf.py
│
├── tests/                       # Tests
│   └── Testprotokoll.md
│
└── README.md
```

---

## 📊 Statistiken

| Metrik | Wert |
|--------|------|
| **Code-Zeilen** | ~2900 |
| **Dokumentation** | ~3000 Zeilen |
| **Dateien** | 20+ |
| **Testfälle** | 25+ |

---

## 👤 Autor

Projektarbeit für Applikationslehre 2. Jahr  
Januar 2026

---

**⭐ Wenn dir das Projekt gefällt, gib ihm einen Star auf GitHub!**
