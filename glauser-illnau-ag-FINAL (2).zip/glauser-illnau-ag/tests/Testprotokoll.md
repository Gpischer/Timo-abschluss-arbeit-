# Test-Suite für Glauser Illnau AG Auftragsverwaltung

## 1. Unit Tests

### UT1: Validierung Kundendaten

#### Testfall UT1.1: PLZ Validierung
**Ziel**: PLZ muss genau 4 Ziffern haben
**Eingabe**: 
- Gültig: "8484", "8340", "1000"
- Ungültig: "84", "848", "84845", "abcd", "84a4"
**Erwartetes Ergebnis**: 
- Gültige PLZ werden akzeptiert
- Ungültige PLZ werden abgelehnt mit Fehlermeldung

**Test durchführen**:
1. Neuen Auftrag öffnen
2. PLZ-Feld mit Testwerten füllen
3. Versuchen zu speichern
4. Fehlermeldung prüfen

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT1.2: Pflichtfelder Kunde
**Ziel**: Name, Adresse, PLZ, Ort müssen ausgefüllt sein
**Eingabe**: Formular ohne Kundendaten abschicken
**Erwartetes Ergebnis**: Browser-Validierung verhindert Absenden

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

### UT2: Validierung Auftragsdaten

#### Testfall UT2.1: Datum und Zeit Pflichtfelder
**Ziel**: Datum und Zeit müssen ausgefüllt sein
**Eingabe**: Formular ohne Datum/Zeit
**Erwartetes Ergebnis**: Formular kann nicht abgeschickt werden

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT2.2: Beschreibung Pflichtfeld
**Ziel**: Beschreibung muss ausgefüllt sein
**Eingabe**: Auftrag ohne Beschreibung
**Erwartetes Ergebnis**: Fehlermeldung "Beschreibung erforderlich"

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT2.3: Mindestens eine Arbeit auswählen
**Ziel**: Mindestens eine auszuführende Arbeit muss gewählt sein
**Eingabe**: Auftrag ohne ausgewählte Arbeiten
**Erwartetes Ergebnis**: Toast-Nachricht "Bitte mindestens eine auszuführende Arbeit auswählen"

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

### UT3: Status-Übergänge

#### Testfall UT3.1: Gültiger Übergang erfasst → disponiert
**Eingabe**: Auftrag mit Status "erfasst" disponieren
**Erwartetes Ergebnis**: Status ändert sich zu "disponiert", Mitarbeiter und Termin werden gesetzt

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT3.2: Gültiger Übergang disponiert → ausgeführt
**Eingabe**: Auftrag mit Status "disponiert" als ausgeführt markieren
**Erwartetes Ergebnis**: Status ändert sich zu "ausgeführt"

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT3.3: Gültiger Übergang ausgeführt → freigegeben
**Eingabe**: Auftrag mit Status "ausgeführt" freigeben
**Erwartetes Ergebnis**: Status ändert sich zu "freigegeben"

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT3.4: Gültiger Übergang freigegeben → verrechnet
**Eingabe**: Auftrag mit Status "freigegeben" verrechnen
**Erwartetes Ergebnis**: Status ändert sich zu "verrechnet"

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT3.5: Ungültiger Übergang erfasst → verrechnet
**Eingabe**: Versuchen, Auftrag direkt von "erfasst" auf "verrechnet" zu setzen
**Erwartetes Ergebnis**: Fehler "Ungültiger Status-Übergang"

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

## 2. Integrationstests

### IT1: Auftrag erfassen und speichern

#### Testfall IT1.1: Vollständiger Workflow - Neuer Kunde
**Schritte**:
1. "Neuer Auftrag" klicken
2. Aktuelles Datum und Zeit prüfen (sollten vorausgefüllt sein)
3. Kundendaten eingeben:
   - Name: "Test AG"
   - Adresse: "Teststrasse 123"
   - PLZ: "8000"
   - Ort: "Zürich"
   - Telefon: "044 123 45 67"
   - Natel: "079 123 45 67"
4. Objektadresse: "dito" (Checkbox aktiv)
5. Verrechnungsadresse: "dito" (Checkbox aktiv)
6. Arbeiten: Reparatur und Sanitär auswählen
7. Beschreibung: "Testauftrag für Integrations-Test"
8. Terminwunsch: "nächste Woche"
9. "Speichern" klicken

**Erwartetes Ergebnis**:
- Toast-Nachricht "Auftrag erfolgreich erstellt!"
- Modal schließt sich
- Neuer Auftrag erscheint in der Liste mit Status "Erfasst"
- Kunde wird in Datenbank gespeichert

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

### IT2: Auftrag disponieren

#### Testfall IT2.1: Mitarbeiter zuweisen und Termin setzen
**Vorbedingung**: Auftrag mit Status "erfasst" vorhanden
**Schritte**:
1. "Disponieren" Button bei erfasstem Auftrag klicken
2. Mitarbeiter auswählen
3. Termin in Zukunft setzen
4. "Disponieren" klicken

**Erwartetes Ergebnis**:
- Toast-Nachricht "Auftrag erfolgreich disponiert!"
- Status ändert zu "Disponiert"
- Mitarbeiter und Termin werden in der Liste angezeigt

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall IT2.2: Disponieren ohne Mitarbeiter
**Schritte**:
1. "Disponieren" öffnen
2. Nur Termin setzen, Mitarbeiter leer lassen
3. "Disponieren" klicken

**Erwartetes Ergebnis**:
- Warning "Bitte alle Felder ausfüllen"
- Formular bleibt offen

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

### IT3: Auftragsdokument generieren

#### Testfall IT3.1: Druckansicht öffnen
**Schritte**:
1. "Details" bei einem Auftrag klicken
2. "Auftrag drucken" klicken

**Erwartetes Ergebnis**:
- Neues Browser-Tab öffnet sich
- Druckversion des Auftrags wird angezeigt
- Alle Daten korrekt formatiert
- Checkboxen zeigen ausgewählte Arbeiten

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

## 3. System-Tests

### ST1: Kompletter Workflow

#### Testfall ST1.1: Von Erfassung bis Verrechnung
**Schritte**:
1. Neuen Auftrag erstellen
2. Auftrag disponieren (Mitarbeiter zuweisen)
3. Als ausgeführt markieren
4. Freigeben
5. Verrechnen

**Erwartetes Ergebnis**:
- Alle Status-Übergänge erfolgreich
- Auftrag endet im Status "Verrechnet"
- Buttons für weitere Status-Änderungen verschwinden

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

### ST2: Filterung und Sortierung

#### Testfall ST2.1: Filter nach Status
**Vorbedingung**: Mindestens ein Auftrag pro Status vorhanden
**Schritte**:
1. Filter auf "Erfasst" setzen
2. Nur erfasste Aufträge sollten angezeigt werden
3. Filter auf "Disponiert" setzen
4. Nur disponierte Aufträge sollten angezeigt werden
5. Filter auf "Alle" zurücksetzen

**Erwartetes Ergebnis**:
- Filterung funktioniert korrekt
- Anzahl wird aktualisiert

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall ST2.2: Suche nach Kunde
**Schritte**:
1. In Suchfeld "Brandenberger" eingeben
2. Nur Aufträge von Kunde Brandenberger anzeigen

**Erwartetes Ergebnis**:
- Live-Suche funktioniert
- Relevante Aufträge werden gefiltert

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

### ST3: PDF-Generierung und Druck

#### Testfall ST3.1: Druckfunktion testen
**Schritte**:
1. Beliebigen Auftrag öffnen
2. "Drucken" klicken
3. Browser-Druckdialog öffnet sich
4. Als PDF speichern oder Druckvorschau prüfen

**Erwartetes Ergebnis**:
- Druckversion ist sauber formatiert
- Keine UI-Elemente (Buttons, Header) im Druck
- Alle Informationen lesbar

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

## 4. Usability-Tests

### UT4: Benutzerfreundlichkeit

#### Testfall UT4.1: Responsive Design
**Schritte**:
1. Fenster auf verschiedene Größen verkleinern
2. Auf Tablet testen (768px)
3. Auf Mobile testen (375px)

**Erwartetes Ergebnis**:
- Layout passt sich an
- Alle Funktionen bleiben nutzbar
- Lesbarkeit gewährleistet

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

#### Testfall UT4.2: Toast-Benachrichtigungen
**Schritte**:
1. Verschiedene Aktionen durchführen
2. Toast-Nachrichten beobachten

**Erwartetes Ergebnis**:
- Toast erscheint rechts unten
- Verschwindet nach 3 Sekunden
- Farbe passend zur Nachricht (grün=Erfolg, rot=Fehler)

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

## 5. Performance-Tests

### PT1: Ladezeiten

#### Testfall PT1.1: Initiales Laden
**Messung**: Zeit bis Aufträge angezeigt werden
**Erwartung**: < 2 Sekunden bei 50 Aufträgen

**Status**: ⬜ Bestanden ⬜ Fehlgeschlagen

---

## Test-Protokoll

**Getestet von**: _______________________
**Datum**: _______________________
**Browser**: _______________________
**Gesamtergebnis**: ⬜ Alle Tests bestanden ⬜ Fehler gefunden

### Fehlerprotokoll:
| Test-ID | Beschreibung | Schweregrad | Status |
|---------|--------------|-------------|--------|
|         |              |             |        |
|         |              |             |        |
|         |              |             |        |

### Anmerkungen:
_______________________________________________________________
_______________________________________________________________
_______________________________________________________________
