# PDF-Generierung - Installation & Verwendung

## 📄 Übersicht

Die Anwendung unterstützt die Generierung von professionellen PDF-Dokumenten für Serviceaufträge. 

## 🔧 Installation

### Voraussetzungen

1. **Python 3** muss installiert sein
2. **reportlab** Library muss installiert werden

### Installation unter Windows (XAMPP)

1. **Python installieren** (falls noch nicht vorhanden):
   - Download: https://www.python.org/downloads/
   - Bei Installation: ✅ "Add Python to PATH" ankreuzen!

2. **reportlab installieren**:
   ```bash
   pip install reportlab
   ```
   
   ODER (falls pip nicht funktioniert):
   ```bash
   python -m pip install reportlab
   ```

3. **Python-Skript ausführbar machen**:
   ```bash
   chmod +x scripts/generate_pdf.py
   ```

### Installation unter Linux/Mac

```bash
# Python sollte bereits installiert sein
python3 --version

# reportlab installieren
pip3 install reportlab

# Skript ausführbar machen
chmod +x scripts/generate_pdf.py
```

## 📋 Verwendung

### Im Browser

1. Auftrag in der Übersicht öffnen
2. Auf **"Details"** klicken
3. **"Auftrag drucken"** Button klicken
4. Im Druckfenster:
   - **🖨️ Drucken** → Druckt direkt
   - **📄 Als PDF herunterladen** → Lädt PDF-Datei herunter

### Manuell (für Tests)

```bash
# Im Projekt-Verzeichnis
cd scripts

# PDF generieren
python3 generate_pdf.py ../test/sample_data.json ../test/output.pdf
```

## 📁 Dateistruktur

```
glauser-illnau-ag/
├── scripts/
│   └── generate_pdf.py          # Python-Skript für PDF-Generierung
├── src/
│   └── php/
│       ├── print.php            # Druckansicht mit PDF-Button
│       └── generate-pdf.php     # PHP-Controller für PDF
```

## 🎨 PDF-Features

Das generierte PDF enthält:
- ✅ Firmen-Header mit Logo-Text
- ✅ Auftragsnummer und Datum
- ✅ Vollständige Kundendaten
- ✅ Objekt- und Verrechnungsadresse
- ✅ Checkboxen für Arbeitstypen
- ✅ Auftragsbeschreibung
- ✅ Terminwunsch
- ✅ Disposition (Mitarbeiter, Termin)
- ✅ Status-Information
- ✅ Footer mit Zeitstempel

## 🐛 Troubleshooting

### Problem: "pip" wird nicht erkannt

**Lösung:**
```bash
python -m pip install reportlab
```

### Problem: "python3: command not found"

**Lösung Windows:**
- Python neu installieren mit "Add to PATH" Option

**Lösung Linux/Mac:**
```bash
sudo apt-get install python3  # Ubuntu/Debian
brew install python3          # Mac
```

### Problem: PDF wird nicht generiert

**Prüfen:**
1. Python installiert? → `python3 --version`
2. reportlab installiert? → `python3 -c "import reportlab; print('OK')"`
3. Fehler-Log prüfen:
   - XAMPP: `xampp/apache/logs/error.log`
   - Browser Console: F12

### Problem: "Permission denied"

**Lösung:**
```bash
chmod +x scripts/generate_pdf.py
```

### Problem: PDF enthält falsche Umlaute

Das Skript verwendet UTF-8 Encoding und sollte deutsche Umlaute korrekt darstellen. Falls nicht:
- Stelle sicher dass die Datenbank UTF-8 verwendet
- Prüfe die PHP-Datei-Encoding

## 🚀 Erweiteru ngsmöglichkeiten

### Logo hinzufügen

```python
from reportlab.lib.utils import ImageReader

# In generate_pdf.py nach "# === HEADER ==="
logo_path = "../assets/logo.png"
if os.path.exists(logo_path):
    img = ImageReader(logo_path)
    c.drawImage(img, margin_left, y_pos, width=30*mm, height=15*mm, preserveAspectRatio=True)
    y_pos -= 20*mm
```

### Weitere Felder hinzufügen

Einfach in `generate_pdf.py` nach dem Schema der anderen Felder hinzufügen:

```python
c.setFont("Helvetica-Bold", 11)
c.drawString(margin_left, y_pos, "NEUES FELD:")
y_pos -= 6*mm

c.setFont("Helvetica", 10)
c.drawString(margin_left, y_pos, data.get('neues_feld', ''))
y_pos -= 10*mm
```

## 📝 Hinweise für Produktion

Für den Einsatz in einer Produktivumgebung sollten folgende Punkte beachtet werden:

1. **Sicherheit:**
   - Input-Validierung in `generate-pdf.php` verstärken
   - Temporäre Dateien sicher löschen
   - Zugriffsberechtigung prüfen

2. **Performance:**
   - PDFs cachen (einmal generiert, mehrfach ausliefern)
   - Queue-System für viele gleichzeitige Anfragen

3. **Fehlerbehandlung:**
   - Bessere Fehler-Logs
   - Nutzer-freundliche Fehlermeldungen
   - Fallback auf HTML-Druck bei PDF-Fehler

## ✅ Checkliste Installation

- [ ] Python 3 installiert
- [ ] pip funktioniert
- [ ] reportlab installiert (`pip install reportlab`)
- [ ] Skript ausführbar (`chmod +x`)
- [ ] Test-PDF generiert
- [ ] Button im Browser funktioniert

## 📞 Support

Bei Problemen:
1. Fehler-Log prüfen
2. Python-Version prüfen: `python3 --version`
3. reportlab prüfen: `python3 -c "import reportlab; print('OK')"`
4. Troubleshooting-Sektion oben lesen

---

**Version:** 1.0  
**Erstellt:** Januar 2026  
**Status:** Produktionsbereit (nach Installation von Python + reportlab)
