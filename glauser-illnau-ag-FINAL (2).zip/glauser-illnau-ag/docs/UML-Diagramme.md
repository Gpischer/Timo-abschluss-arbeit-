# UML Diagramme - Glauser Illnau AG

## Use Case Diagramm

```plantuml
@startuml
left to right direction
skinparam packageStyle rectangle

actor "Administration" as Admin
actor "Bereichsleiter" as BL
actor "Mitarbeiter" as MA

rectangle "Glauser Illnau AG Auftragsverwaltung" {
  usecase "Auftrag erfassen" as UC1
  usecase "Auftragsdokument drucken" as UC2
  usecase "Aufträge einsehen" as UC3
  usecase "Auftrag disponieren" as UC4
  usecase "Auftrag als ausgeführt markieren" as UC5
  usecase "Rapport freigeben" as UC6
  usecase "Auftrag verrechnen" as UC7
  usecase "Auftragsübersicht filtern" as UC8
}

Admin --> UC1
Admin --> UC2
Admin --> UC7
Admin --> UC3

BL --> UC3
BL --> UC4
BL --> UC6
BL --> UC8
BL --> UC2

MA --> UC5
MA --> UC3

UC5 ..> UC3 : <<include>>
UC4 ..> UC3 : <<include>>
UC6 ..> UC3 : <<include>>

@enduml
```

## Klassendiagramm

```plantuml
@startuml

class Auftrag {
  - auftrag_id: int
  - datum: Date
  - zeit: Time
  - kunde_id: int
  - objekt_adresse: String
  - verrechnung_adresse: String
  - arbeiten_reparatur: boolean
  - arbeiten_sanitaer: boolean
  - arbeiten_heizung: boolean
  - arbeiten_garantie: boolean
  - beschreibung: String
  - termin_wunsch: String
  - status: Status
  - mitarbeiter_id: int
  - termin: Date
  --
  + erstellen(): boolean
  + disponieren(mitarbeiter_id, termin): boolean
  + statusAendern(neuerStatus): boolean
  + getDaten(): Array
  + drucken(): void
}

class Kunde {
  - kunde_id: int
  - name: String
  - adresse: String
  - plz: String
  - ort: String
  - telefon: String
  - natel: String
  --
  + speichern(): boolean
  + laden(id): Kunde
  + suchen(begriff): Array
  + validieren(): boolean
}

class Mitarbeiter {
  - mitarbeiter_id: int
  - name: String
  - rolle: Rolle
  --
  + laden(id): Mitarbeiter
  + getAlle(): Array
  + getByRolle(rolle): Array
}

enum Status {
  ERFASST
  DISPONIERT
  AUSGEFUEHRT
  FREIGEGEBEN
  VERRECHNET
}

enum Rolle {
  ADMINISTRATION
  BEREICHSLEITER
  MITARBEITER
}

Auftrag "1" -- "1" Kunde : gehört zu >
Auftrag "0..*" -- "0..1" Mitarbeiter : zugewiesen zu >
Auftrag --> Status : hat >
Mitarbeiter --> Rolle : hat >

@enduml
```

## Aktivitätsdiagramm - Auftrag erstellen

```plantuml
@startuml
start
:Benutzer klickt "Neuer Auftrag";
:Formular öffnet sich;
:Datum und Zeit werden vorausgefüllt;

:Benutzer gibt Kundendaten ein;

if (Alle Pflichtfelder ausgefüllt?) then (Nein)
  :Fehlermeldung anzeigen;
  stop
else (Ja)
  if (PLZ valide?) then (Nein)
    :Fehlermeldung "PLZ ungültig";
    stop
  else (Ja)
    if (Mindestens eine Arbeit gewählt?) then (Nein)
      :Toast "Bitte Arbeit wählen";
      stop
    else (Ja)
      :Daten an Server senden;
      
      if (Kunde existiert?) then (Ja)
        :Bestehenden Kunde verwenden;
      else (Nein)
        :Neuen Kunde anlegen;
      endif
      
      :Auftrag in DB speichern;
      :Status "erfasst" setzen;
      :Success-Toast anzeigen;
      :Modal schließen;
      :Auftragsliste aktualisieren;
      stop
    endif
  endif
endif

@enduml
```

## Sequenzdiagramm - Auftrag disponieren

```plantuml
@startuml
actor Bereichsleiter
participant "Browser" as UI
participant "API" as API
database "Datenbank" as DB

Bereichsleiter -> UI: Klickt "Disponieren"
UI -> UI: Modal öffnen
UI -> API: GET getMitarbeiter()
API -> DB: SELECT mitarbeiter
DB --> API: Mitarbeiter-Liste
API --> UI: JSON Response
UI -> UI: Dropdown füllen

Bereichsleiter -> UI: Wählt Mitarbeiter
Bereichsleiter -> UI: Setzt Termin
Bereichsleiter -> UI: Klickt "Disponieren"

UI -> UI: Validierung
alt Validierung erfolgreich
  UI -> API: POST disponieren()\n{auftrag_id, mitarbeiter_id, termin}
  API -> DB: UPDATE auftrag\nSET status='disponiert',\nmitarbeiter_id, termin
  DB --> API: Success
  API --> UI: {success: true}
  UI -> UI: Toast "Erfolgreich disponiert"
  UI -> UI: Modal schließen
  UI -> API: GET getAuftraege()
  API -> DB: SELECT auftraege
  DB --> API: Auftragsliste
  API --> UI: JSON Response
  UI -> UI: Liste aktualisieren
else Validierung fehlgeschlagen
  UI -> UI: Toast "Bitte alle Felder ausfüllen"
end

@enduml
```

## Entity-Relationship-Diagramm (ERD)

```plantuml
@startuml

entity "kunde" as kunde {
  * kunde_id : INT <<PK>>
  --
  * name : VARCHAR(255)
  * adresse : VARCHAR(255)
  * plz : VARCHAR(10)
  * ort : VARCHAR(100)
  telefon : VARCHAR(20)
  natel : VARCHAR(20)
  erstellt_am : TIMESTAMP
  aktualisiert_am : TIMESTAMP
}

entity "auftrag" as auftrag {
  * auftrag_id : INT <<PK>>
  --
  * datum : DATE
  * zeit : TIME
  * kunde_id : INT <<FK>>
  objekt_adresse : VARCHAR(255)
  verrechnung_adresse : VARCHAR(255)
  arbeiten_reparatur : BOOLEAN
  arbeiten_sanitaer : BOOLEAN
  arbeiten_heizung : BOOLEAN
  arbeiten_garantie : BOOLEAN
  * beschreibung : TEXT
  termin_wunsch : VARCHAR(100)
  * status : ENUM
  mitarbeiter_id : INT <<FK>>
  termin : DATE
  erstellt_am : TIMESTAMP
  aktualisiert_am : TIMESTAMP
}

entity "mitarbeiter" as mitarbeiter {
  * mitarbeiter_id : INT <<PK>>
  --
  * name : VARCHAR(255)
  * rolle : ENUM
  erstellt_am : TIMESTAMP
}

kunde ||--o{ auftrag : "hat"
mitarbeiter ||--o{ auftrag : "bearbeitet"

@enduml
```

## Zustandsdiagramm - Auftragsstatus

```plantuml
@startuml

[*] --> Erfasst : Auftrag erstellen

Erfasst --> Disponiert : disponieren()\n[Mitarbeiter + Termin]

Disponiert --> Ausgefuehrt : als ausgeführt markieren()\n[durch Mitarbeiter]

Ausgefuehrt --> Freigegeben : freigeben()\n[durch Bereichsleiter]

Freigegeben --> Verrechnet : verrechnen()\n[durch Administration]

Verrechnet --> [*] : Abgeschlossen

note right of Erfasst
  Status nach Erfassung
  Noch kein Mitarbeiter zugewiesen
end note

note right of Disponiert
  Mitarbeiter zugewiesen
  Termin geplant
end note

note right of Ausgefuehrt
  Arbeit erledigt
  Wartet auf Freigabe
end note

note right of Freigegeben
  Rapport geprüft
  Bereit zur Verrechnung
end note

note right of Verrechnet
  Endstatus
  Keine weiteren Änderungen
end note

@enduml
```

---

## Verwendung der Diagramme

Diese Diagramme sind im PlantUML-Format erstellt. Um sie zu visualisieren:

### Option 1: Online
Besuche: https://www.plantuml.com/plantuml/uml/
Kopiere den Code und füge ihn ein.

### Option 2: VS Code Plugin
1. Installiere "PlantUML" Extension
2. Öffne diese Datei
3. Drücke Alt+D für Preview

### Option 3: Kommandozeile
```bash
plantuml diagramme.puml
```

Generiert PNG-Dateien für jedes Diagramm.
