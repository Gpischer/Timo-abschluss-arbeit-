# Entity-Relationship-Modell (ERM) - Detailliert
## Glauser Illnau AG - Auftragsverwaltung

---

## 📊 Übersicht

Das ERM beschreibt die Datenstruktur der Auftragsverwaltung mit allen Entitäten, Attributen, Datentypen und Beziehungen.

---

## 🔷 Entitäten und Attribute

### Entität: KUNDE

| Attribut | Datentyp | Länge | Constraints | Beschreibung |
|----------|----------|-------|-------------|--------------|
| **kunde_id** | INT | - | PRIMARY KEY, AUTO_INCREMENT | Eindeutige Kunden-ID |
| name | VARCHAR | 255 | NOT NULL | Name des Kunden |
| adresse | VARCHAR | 255 | NOT NULL | Straße und Hausnummer |
| plz | VARCHAR | 10 | NOT NULL | Postleitzahl (4-stellig in CH) |
| ort | VARCHAR | 100 | NOT NULL | Ortsname |
| telefon | VARCHAR | 20 | NULL | Festnetznummer |
| natel | VARCHAR | 20 | NULL | Mobilnummer |
| erstellt_am | TIMESTAMP | - | DEFAULT CURRENT_TIMESTAMP | Erstellungsdatum |
| aktualisiert_am | TIMESTAMP | - | DEFAULT CURRENT_TIMESTAMP ON UPDATE | Letzte Änderung |

**Primärschlüssel**: kunde_id  
**Fremdschlüssel**: keine  
**Indizes**: name, ort

**Wertebereich**:
- PLZ: 1000-9999 (Schweizer PLZ)
- Telefon/Natel: Format: 0XX XXX XX XX

---

### Entität: MITARBEITER

| Attribut | Datentyp | Länge | Constraints | Beschreibung |
|----------|----------|-------|-------------|--------------|
| **mitarbeiter_id** | INT | - | PRIMARY KEY, AUTO_INCREMENT | Eindeutige Mitarbeiter-ID |
| name | VARCHAR | 255 | NOT NULL | Vor- und Nachname |
| rolle | ENUM | - | NOT NULL | Rolle im Unternehmen |
| erstellt_am | TIMESTAMP | - | DEFAULT CURRENT_TIMESTAMP | Erstellungsdatum |

**Primärschlüssel**: mitarbeiter_id  
**Fremdschlüssel**: keine  
**Indizes**: rolle

**Wertebereich Rolle**:
- 'administration'
- 'bereichsleiter'
- 'mitarbeiter'

---

### Entität: AUFTRAG

| Attribut | Datentyp | Länge | Constraints | Beschreibung |
|----------|----------|-------|-------------|--------------|
| **auftrag_id** | INT | - | PRIMARY KEY, AUTO_INCREMENT | Eindeutige Auftrags-ID |
| datum | DATE | - | NOT NULL | Datum der Auftragsannahme |
| zeit | TIME | - | NOT NULL | Uhrzeit der Auftragsannahme |
| kunde_id | INT | - | FOREIGN KEY, NOT NULL | Referenz zu KUNDE |
| objekt_adresse | VARCHAR | 255 | NULL | Adresse des Objekts |
| verrechnung_adresse | VARCHAR | 255 | NULL | Rechnungsadresse |
| arbeiten_reparatur | BOOLEAN | - | DEFAULT FALSE | Reparaturarbeiten gewählt |
| arbeiten_sanitaer | BOOLEAN | - | DEFAULT FALSE | Sanitärarbeiten gewählt |
| arbeiten_heizung | BOOLEAN | - | DEFAULT FALSE | Heizungsarbeiten gewählt |
| arbeiten_garantie | BOOLEAN | - | DEFAULT FALSE | Garantiearbeiten gewählt |
| beschreibung | TEXT | - | NOT NULL | Detaillierte Auftragsbeschreibung |
| termin_wunsch | VARCHAR | 100 | NULL | Gewünschter Termin (Freitext) |
| status | ENUM | - | NOT NULL, DEFAULT 'erfasst' | Aktueller Status |
| mitarbeiter_id | INT | - | FOREIGN KEY, NULL | Zugewiesener Mitarbeiter |
| termin | DATE | - | NULL | Geplanter Ausführungstermin |
| erstellt_am | TIMESTAMP | - | DEFAULT CURRENT_TIMESTAMP | Erstellungsdatum |
| aktualisiert_am | TIMESTAMP | - | DEFAULT CURRENT_TIMESTAMP ON UPDATE | Letzte Änderung |

**Primärschlüssel**: auftrag_id  
**Fremdschlüssel**: 
- kunde_id → KUNDE(kunde_id)
- mitarbeiter_id → MITARBEITER(mitarbeiter_id)

**Indizes**: datum, status, kunde_id, mitarbeiter_id

**Wertebereich Status**:
- 'erfasst' (Standard)
- 'disponiert'
- 'ausgefuehrt'
- 'freigegeben'
- 'verrechnet'

**Wertebereich Objekt-/Verrechnungsadresse**:
- NULL = nicht angegeben
- 'dito' = gleich wie Kundenadresse
- Andere Adresse als String

---

## 🔗 Beziehungen (Relationships)

### 1. KUNDE ← AUFTRAG (1:n)

**Beziehungstyp**: 1:n (One-to-Many)

**Beschreibung**: 
- Ein Kunde kann **mehrere Aufträge** haben
- Ein Auftrag gehört zu **genau einem Kunden**

**Kardinalität**:
- KUNDE (1,n) ← AUFTRAG (1,1)
- Minimum 1, Maximum n Aufträge pro Kunde
- Genau 1 Kunde pro Auftrag

**Implementierung**:
```sql
FOREIGN KEY (kunde_id) 
REFERENCES kunde(kunde_id) 
ON DELETE RESTRICT
```

**Geschäftsregel**: 
- Kunde kann nicht gelöscht werden, wenn Aufträge existieren (RESTRICT)
- Beim Erfassen eines Auftrags wird automatisch geprüft ob Kunde existiert

---

### 2. MITARBEITER ← AUFTRAG (0:n)

**Beziehungstyp**: 0:n (Zero-to-Many)

**Beschreibung**: 
- Ein Mitarbeiter kann **mehrere Aufträge** bearbeiten
- Ein Auftrag kann **keinem oder einem Mitarbeiter** zugewiesen sein

**Kardinalität**:
- MITARBEITER (0,n) ← AUFTRAG (0,1)
- Minimum 0, Maximum n Aufträge pro Mitarbeiter
- 0 oder 1 Mitarbeiter pro Auftrag

**Implementierung**:
```sql
FOREIGN KEY (mitarbeiter_id) 
REFERENCES mitarbeiter(mitarbeiter_id) 
ON DELETE SET NULL
```

**Geschäftsregel**: 
- Bei Status 'erfasst' ist mitarbeiter_id = NULL
- Ab Status 'disponiert' muss mitarbeiter_id gesetzt sein
- Bei Löschen des Mitarbeiters wird mitarbeiter_id auf NULL gesetzt

---

## 📐 Grafische Darstellung (Chen-Notation)

```
┌─────────────┐
│   KUNDE     │
├─────────────┤
│ kunde_id PK │
│ name        │
│ adresse     │
│ plz         │
│ ort         │
│ telefon     │
│ natel       │
└─────────────┘
      │
      │ 1
      │
      ◇ hat
      │
      │ n
      │
┌─────────────┐
│  AUFTRAG    │
├─────────────┤
│ auftrag_id  │──────┐
│ datum       │      │
│ zeit        │      │
│ kunde_id FK │──────┘
│ beschreibung│
│ status      │
│ mitarbeiter │──────┐
└─────────────┘      │
      │              │
      │ n            │ 1
      │              │
      ◇ wird         │
      │ bearbeitet   │
      │ von          │
      │ 0..1         │
      │              │
┌──────────────┐     │
│ MITARBEITER  │     │
├──────────────┤     │
│mitarbeiter_id│─────┘
│ name         │
│ rolle        │
└──────────────┘
```

---

## 🔐 Integritätsbedingungen

### Referenzielle Integrität

1. **Kunde → Auftrag**
   - Jeder Auftrag muss einen gültigen Kunden referenzieren
   - Kunde kann nicht gelöscht werden wenn Aufträge existieren

2. **Mitarbeiter → Auftrag**
   - Mitarbeiter-Referenz ist optional (NULL erlaubt)
   - Bei Löschen wird Referenz auf NULL gesetzt

### Domänenintegrität

1. **Status-Übergänge**
   - erfasst → disponiert ✅
   - disponiert → ausgefuehrt ✅
   - ausgefuehrt → freigegeben ✅
   - freigegeben → verrechnet ✅
   - Andere Übergänge ❌

2. **Rollen-Berechtigungen**
   - administration: Erfassen, Verrechnen
   - bereichsleiter: Disponieren, Freigeben
   - mitarbeiter: Ausführen

3. **Datenvalidierung**
   - PLZ: Genau 4 Ziffern
   - Telefon: Schweizer Format
   - Datum: Nicht in der Vergangenheit (bei Termin)
   - Mindestens eine Arbeit ausgewählt

---

## 📊 Normalisierung

### 1. Normalform (1NF) ✅
- Alle Attribute sind atomar
- Keine mehrwertigen Attribute
- Jede Tabelle hat einen Primärschlüssel

### 2. Normalform (2NF) ✅
- 1NF erfüllt
- Alle Nicht-Schlüssel-Attribute sind voll funktional abhängig vom Primärschlüssel
- Keine partiellen Abhängigkeiten

### 3. Normalform (3NF) ✅
- 2NF erfüllt
- Keine transitiven Abhängigkeiten
- Jedes Nicht-Schlüssel-Attribut ist direkt vom Primärschlüssel abhängig

**Begründung**:
- KUNDE: name, adresse etc. abhängig nur von kunde_id
- MITARBEITER: name, rolle abhängig nur von mitarbeiter_id
- AUFTRAG: Alle Attribute abhängig nur von auftrag_id

---

## 🎯 Designentscheidungen

### 1. Separate Kunde-Tabelle
**Vorteil**: 
- Wiederverwendung bei mehreren Aufträgen
- Zentrale Kundenverwaltung
- Konsistente Daten

**Nachteil**: 
- Zusätzlicher JOIN bei Abfragen

### 2. Boolean für Arbeiten statt eigene Tabelle
**Vorteil**: 
- Einfache Struktur
- Schnelle Abfragen
- Maximal 4 Optionen überschaubar

**Nachteil**: 
- Nicht erweiterbar ohne Schema-Änderung

### 3. ENUM für Status
**Vorteil**: 
- Datenbank-Validierung
- Klare Werte
- Speicherplatz-effizient

**Nachteil**: 
- Änderungen erfordern ALTER TABLE

### 4. Optionaler Mitarbeiter (NULL)
**Vorteil**: 
- Flexibilität (Auftrag kann erfasst werden ohne sofort disponiert zu sein)
- Realitätsnah

**Nachteil**: 
- NULL-Handling notwendig

---

## 📈 Erweiterungsmöglichkeiten

Für zukünftige Versionen:

1. **Tabelle: Material**
   - material_id (PK)
   - name, preis, einheit
   - Beziehung zu Auftrag (n:m)

2. **Tabelle: Zeiterfassung**
   - zeit_id (PK)
   - auftrag_id (FK)
   - mitarbeiter_id (FK)
   - von, bis, pause

3. **Tabelle: Dokumente**
   - dokument_id (PK)
   - auftrag_id (FK)
   - typ, pfad, hochgeladen_am

4. **Tabelle: Statushistorie**
   - historie_id (PK)
   - auftrag_id (FK)
   - alter_status, neuer_status
   - geaendert_am, geaendert_von

---

**Version**: 1.0  
**Erstellt**: Januar 2026  
**Status**: Final für Projektabgabe
