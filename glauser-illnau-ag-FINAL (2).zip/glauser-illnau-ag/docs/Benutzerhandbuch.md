# Benutzerhandbuch - Glauser Illnau AG Auftragsverwaltung

## Inhaltsverzeichnis
1. [Einleitung](#einleitung)
2. [Benutzeroberfläche](#benutzeroberfläche)
3. [Aufträge verwalten](#aufträge-verwalten)
4. [Häufige Aufgaben](#häufige-aufgaben)
5. [Tipps & Tricks](#tipps--tricks)
6. [Fehlerbehebung](#fehlerbehebung)

---

## Einleitung

Die Auftragsverwaltung ermöglicht die digitale Erfassung und Verwaltung von Serviceaufträgen. Dieses System ersetzt die bisherigen Papier-Auftragsblätter und ermöglicht einen effizienten Workflow.

### Hauptfunktionen
- ✅ Digitale Auftragserfassung
- ✅ Automatische Kundenverwaltung
- ✅ Übersichtliche Status-Verwaltung
- ✅ Professionelle Auftragsdokumente
- ✅ Filterung und Suche

---

## Benutzeroberfläche

### Hauptbildschirm

```
┌─────────────────────────────────────────────────────────┐
│ GLAUSER ILLNAU AG                    [+ Neuer Auftrag]  │
│ Auftragsverwaltungssystem                               │
├─────────────────────────────────────────────────────────┤
│ Status: [Alle ▼]  🔍 [Suche...]       Gesamt: 8        │
├─────────────────────────────────────────────────────────┤
│ Nr.  │ Datum  │ Kunde       │ Status    │ Aktionen     │
├──────┼────────┼─────────────┼───────────┼──────────────┤
│ 1234 │ 23.09. │ B.Brandenb. │ Erfasst   │ [Details]... │
│ 1235 │ 24.09. │ R.Rutis.    │ Disponiert│ [Details]... │
└─────────────────────────────────────────────────────────┘
```

### Elemente

**1. Header**
- Logo und Titel
- "Neuer Auftrag" Button (oben rechts)

**2. Toolbar**
- Status-Filter Dropdown
- Suchfeld
- Statistik (Anzahl Aufträge)

**3. Auftragsliste**
- Tabelle mit allen Aufträgen
- Sortiert nach Status und Datum
- Aktionsbuttons pro Auftrag

---

## Aufträge verwalten

### 1. Neuen Auftrag erfassen

#### Schritt-für-Schritt

**Schritt 1: Formular öffnen**
- Klicke auf den Button **"+ Neuer Auftrag"**
- Ein Modal-Fenster öffnet sich
- Datum und Uhrzeit sind bereits vorausgefüllt

**Schritt 2: Kundendaten eingeben**

Pflichtfelder (mit * markiert):
- **Name**: z.B. "Frau Beatrice Brandenberger"
- **Adresse**: z.B. "Obderdorfstrasse 11"
- **PLZ**: Genau 4 Ziffern, z.B. "8484"
- **Ort**: z.B. "Weisslingen"

Optional:
- **Telefon**: z.B. "052 123 45 67"
- **Natel**: z.B. "079 123 45 67"

**Schritt 3: Adressen festlegen**

*Objektadresse:*
- ☑️ "Gleich wie Kundenadresse" → verwendet Kundenadresse
- ☐ Abwählen um andere Adresse einzugeben

*Verrechnungsadresse:*
- ☑️ "Gleich wie Kundenadresse" → verwendet Kundenadresse
- ☐ Abwählen um andere Adresse einzugeben

**Schritt 4: Arbeiten auswählen**

Mindestens eine Option wählen:
- ☐ Reparatur
- ☐ Sanitär
- ☐ Heizung
- ☐ Garantie

**Schritt 5: Beschreibung eingeben**

Ausführliche Beschreibung des Problems oder der Arbeit:
```
Beispiel:
Wasserhahn in der Küche tropft/undicht.
Seit gestern Abend. Dringend.
```

**Schritt 6: Terminwunsch (optional)**
```
Beispiele:
- "so schnell wie möglich"
- "diese Woche"
- "nächsten Montag"
- "nach Vereinbarung"
```

**Schritt 7: Speichern**
- Klicke auf **"Auftrag speichern"**
- Bei Erfolg erscheint eine grüne Bestätigung
- Das Formular schließt sich automatisch
- Der neue Auftrag erscheint in der Liste

#### Validierung

Das System prüft automatisch:
- ✅ Alle Pflichtfelder ausgefüllt
- ✅ PLZ hat genau 4 Ziffern
- ✅ Mindestens eine Arbeit ausgewählt

Bei Fehlern erscheint eine Warnung:
```
⚠️ Bitte mindestens eine auszuführende Arbeit auswählen
```

---

### 2. Auftrag disponieren

**Wer**: Bereichsleiter  
**Status**: Auftrag muss "Erfasst" sein

#### Vorgang

1. **Auftrag finden**
   - In der Liste nach erfasstem Auftrag suchen
   - Eventuell Filter auf "Erfasst" setzen

2. **Disponieren-Dialog öffnen**
   - Klicke auf **"Disponieren"** Button
   - Ein kleines Modal öffnet sich

3. **Mitarbeiter zuweisen**
   - Wähle aus Dropdown-Liste
   - Nur Mitarbeiter (keine Administration)

4. **Termin festlegen**
   - Wähle Datum mit Kalender
   - Sollte in der Zukunft liegen

5. **Bestätigen**
   - Klicke **"Disponieren"**
   - Status ändert zu "Disponiert"
   - Mitarbeiter und Termin werden gespeichert

---

### 3. Auftragsstatus ändern

#### Status-Workflow

```
Erfasst
   ↓ [Disponieren]
Disponiert
   ↓ [Ausgeführt]
Ausgeführt
   ↓ [Freigeben]
Freigegeben
   ↓ [Verrechnen]
Verrechnet (Ende)
```

#### Wer darf was?

| Status-Änderung | Berechtigung |
|-----------------|--------------|
| Disponieren | Bereichsleiter |
| Als ausgeführt markieren | Mitarbeiter |
| Freigeben | Bereichsleiter |
| Verrechnen | Administration |

#### Vorgang

1. **Button klicken**
   - Je nach Status erscheint passender Button
   - z.B. "Ausgeführt" bei disponiertem Auftrag

2. **Bestätigen**
   - Sicherheitsabfrage erscheint
   - Klicke "OK"

3. **Prüfen**
   - Status ändert sich sofort
   - Grüne Bestätigung erscheint
   - Liste wird aktualisiert

---

### 4. Auftragsdokument drucken

#### Variante A: Aus der Liste

1. Klicke **"Details"** bei gewünschtem Auftrag
2. Im Detail-Modal auf **"Auftrag drucken"** klicken

#### Variante B: Direkt aus der Liste

1. Klicke **"Drucken"** Button in der Aktions-Spalte

#### Was passiert

- Neues Browser-Tab öffnet sich
- Professionell formatiertes Dokument
- Alle Auftragsinformationen
- Checkboxen für gewählte Arbeiten

#### Drucken oder speichern

**Option 1: Drucken**
- Klicke Drucker-Symbol im Tab
- Wähle Drucker
- Drucke Dokument

**Option 2: Als PDF speichern**
- Klicke Drucker-Symbol
- Wähle "Als PDF speichern"
- Speichere auf Computer

---

## Häufige Aufgaben

### Auftrag suchen

#### Nach Kunde suchen
1. Gib Kundenname ins Suchfeld ein
2. System filtert live während Eingabe
3. Nur passende Aufträge werden angezeigt

```
🔍 [Brandenberger]
→ Zeigt nur Aufträge von Brandenberger
```

#### Nach Status filtern
1. Öffne Status-Dropdown
2. Wähle gewünschten Status
3. Nur Aufträge mit diesem Status werden angezeigt

```
Status: [Disponiert ▼]
→ Zeigt nur disponierte Aufträge
```

#### Kombination
Beide Filter können gleichzeitig verwendet werden:
```
Status: [Erfasst ▼]  🔍 [Meier]
→ Zeigt erfasste Aufträge von Kunde Meier
```

---

### Auftrag-Details ansehen

1. Klicke **"Details"** in der Auftrags-Zeile
2. Modal mit allen Informationen öffnet sich

**Angezeigte Informationen:**
- Auftragsnummer, Datum, Zeit, Status
- Vollständige Kundendaten
- Objekt- und Verrechnungsadresse
- Alle ausgewählten Arbeiten
- Beschreibung
- Terminwunsch
- Zugewiesener Mitarbeiter (falls disponiert)
- Geplanter Termin (falls disponiert)

---

### Mehrere Aufträge bearbeiten

**Szenario**: 5 Aufträge müssen disponiert werden

**Effizient vorgehen:**
1. Setze Filter auf "Erfasst"
2. Disponiere ersten Auftrag
3. Nach Schließen des Modals ist nächster Auftrag schon sichtbar
4. Disponiere nächsten Auftrag
5. Wiederhole bis alle disponiert sind

---

## Tipps & Tricks

### ⚡ Schnellere Eingabe

**Tipp 1: Tab-Navigation**
- Nutze Tab-Taste zwischen Feldern
- Spart Zeit beim Erfassen

**Tipp 2: Kundendaten wiederverwenden**
- System erkennt automatisch bestehende Kunden
- Bei gleichen Daten (Name, PLZ, Ort) wird Kunde verlinkt
- Keine doppelten Kunden-Einträge

**Tipp 3: Standardwerte**
- "dito" für gleiche Adressen (Checkboxen nutzen)
- Datum und Zeit sind vorausgefüllt

### 📊 Übersicht behalten

**Tipp 1: Status-Filter nutzen**
```
Morgens:    [Erfasst]     → Priorisierung
Mittags:    [Disponiert]  → Tageskontrolle  
Abends:     [Ausgeführt]  → Freigabe
```

**Tipp 2: Statistik im Blick**
- Rechts oben zeigt Gesamtzahl
- Bei gefilterter Ansicht: gefilterte Anzahl

### 🖨️ Drucken optimieren

**Tipp 1: Mehrere Aufträge**
- Öffne mehrere Druck-Tabs
- Dann alle zusammen drucken

**Tipp 2: PDF-Archiv**
- Speichere wichtige Aufträge als PDF
- Benenne Datei: `Auftrag_1234_Brandenberger.pdf`

### 🔄 Workflow-Tipps

**Für Bereichsleiter:**
```
1. Morgens: Neue Aufträge disponieren
2. Mittags: Kontrolle disponierter Aufträge
3. Abends: Ausgeführte Aufträge freigeben
```

**Für Mitarbeiter:**
```
1. Eigene Aufträge mit Filter finden
2. Nach Ausführung als "Ausgeführt" markieren
3. Bei Problemen Bereichsleiter informieren
```

---

## Fehlerbehebung

### Häufige Probleme

#### Problem: "PLZ muss 4 Ziffern haben"
**Lösung**: 
- Nur Zahlen eingeben (keine Buchstaben)
- Genau 4 Ziffern (nicht 3 oder 5)
- Beispiel: ✅ 8484  ❌ 848  ❌ 84845

#### Problem: "Bitte mindestens eine Arbeit auswählen"
**Lösung**:
- Mindestens ein Checkbox aktivieren
- Reparatur ODER Sanitär ODER Heizung ODER Garantie

#### Problem: Auftrag verschwindet nach Filter
**Lösung**:
- Setze Filter zurück auf "Alle"
- Oder prüfe ob richtiger Status gewählt

#### Problem: "Auftrag konnte nicht disponiert werden"
**Lösung**:
- Auftrag muss Status "Erfasst" haben
- Bereits disponierte Aufträge können nicht neu disponiert werden

#### Problem: Druckansicht zeigt falsche Daten
**Lösung**:
- Tab aktualisieren (F5)
- Oder Tab schließen und neu öffnen

### Technische Probleme

#### Seite lädt nicht
1. Prüfe ob Apache und MySQL laufen
2. Öffne http://localhost/glauser-illnau-ag/
3. Prüfe Browser-Konsole (F12) auf Fehler

#### Daten werden nicht gespeichert
1. Prüfe Datenbankverbindung
2. Kontrolliere `config.php` Einstellungen
3. Prüfe ob Datenbank existiert

#### Filter funktioniert nicht
1. Seite neu laden (F5)
2. Browser-Cache leeren
3. In anderem Browser testen

---

## Tastenkombinationen

| Aktion | Tastenkombination |
|--------|-------------------|
| Modal schließen | ESC |
| Formular absenden | Enter (in Textfeld) |
| Zwischen Feldern wechseln | Tab |
| Checkbox aktivieren | Leertaste |
| Drucken | Strg + P |
| Seite neu laden | F5 |

---

## Support & Kontakt

Bei Fragen oder Problemen:
1. Konsultiere dieses Handbuch
2. Prüfe das Testprotokoll
3. Kontaktiere den Administrator

---

**Version**: 1.0  
**Stand**: Januar 2026  
**Erstellt für**: Glauser Illnau AG
