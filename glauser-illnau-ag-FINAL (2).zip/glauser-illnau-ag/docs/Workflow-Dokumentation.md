# Workflow-Dokumentation
## Interner Ablauf - Glauser Illnau AG

---

## 📋 Übersicht

Diese Dokumentation zeigt, wie der **6-stufige interne Ablauf** der Firma Glauser Illnau AG im Auftragsverwaltungssystem digital abgebildet wurde.

---

## 🔄 Kompletter Workflow

```
┌─────────────────────────────────────────────────────────────────┐
│                    INTERNER ABLAUF                               │
└─────────────────────────────────────────────────────────────────┘

1️⃣  ADMINISTRATION
    ↓ Auftrag annehmen (telefonisch)
    ↓ System: "Neuer Auftrag" erfassen
    ↓
    [Status: ERFASST]
    
2️⃣  BEREICHSLEITER
    ↓ Auftrag disponieren/planen
    ↓ System: Mitarbeiter zuweisen + Termin festlegen
    ↓
    [Status: DISPONIERT]
    
3️⃣  MITARBEITER
    ↓ Auftrag ausführen und rapportieren
    ↓ System: "Als ausgeführt markieren"
    ↓
    [Status: AUSGEFÜHRT]
    
4️⃣  BEREICHSLEITER
    ↓ Ausführung administrativ überwachen
    ↓ System: Auftragsübersicht + Filter nutzen
    ↓
    [Status: bleibt AUSGEFÜHRT]
    
5️⃣  BEREICHSLEITER
    ↓ Rapport prüfen und zur Verrechnung freigeben
    ↓ System: "Freigeben" Button
    ↓
    [Status: FREIGEGEBEN]
    
6️⃣  ADMINISTRATION
    ↓ Auftrag verrechnen
    ↓ System: "Verrechnen" Button
    ↓
    [Status: VERRECHNET] ✅ Abgeschlossen
```

---

## 📊 Detaillierte Schritt-für-Schritt Beschreibung

### Schritt 1: Auftrag annehmen (Administration)

**Rolle:** Geschäftsleiter / Administration

**Aufgabe:** 
- Kunde ruft an (z.B. wegen tropfendem Wasserhahn)
- Administration nimmt Auftrag entgegen

**System-Funktion:**
1. Button **"+ Neuer Auftrag"** klicken
2. Modal öffnet sich
3. Formular ausfüllen:
   - Datum & Zeit (automatisch vorausgefüllt)
   - Kundendaten (Name, Adresse, PLZ, Ort, Telefon, Natel)
   - Objektadresse (dito oder andere)
   - Verrechnungsadresse (dito oder andere)
   - Auszuführende Arbeiten (Checkboxen)
   - Beschreibung des Problems
   - Terminwunsch (z.B. "so schnell wie möglich")
4. **"Speichern"** klicken
5. Auftrag wird erstellt mit Status **"erfasst"**

**Screenshot-Referenz:** UI-Mockups.md → "Modal - Neuer Auftrag"

**Ausgabe:**
- Auftragsnummer wird generiert (z.B. 1234)
- Auftrag erscheint in der Übersicht
- Status: **ERFASST** (blau)

---

### Schritt 2: Auftrag disponieren (Bereichsleiter)

**Rolle:** Bereichsleiter

**Aufgabe:**
- Auftrag einem Mitarbeiter zuweisen
- Termin für Ausführung festlegen

**System-Funktion:**
1. In der Auftragsübersicht nach Status **"Erfasst"** filtern
2. Bei gewünschtem Auftrag auf **"Disponieren"** klicken
3. Modal öffnet sich
4. **Mitarbeiter** aus Dropdown wählen (z.B. "Peter Müller")
5. **Termin** festlegen (Datumswähler)
6. **"Disponieren"** klicken
7. Status ändert sich zu **"disponiert"**

**Screenshot-Referenz:** UI-Mockups.md → "Modal - Disponieren"

**Validierung:**
- Mitarbeiter muss ausgewählt sein
- Termin muss gesetzt sein
- Nur Mitarbeiter mit Rolle "mitarbeiter" oder "bereichsleiter" wählbar

**Ausgabe:**
- Status: **DISPONIERT** (orange/gelb)
- Mitarbeiter-Name wird in Tabelle angezeigt
- Termin wird in Tabelle angezeigt

---

### Schritt 3: Auftrag ausführen (Mitarbeiter)

**Rolle:** Mitarbeiter

**Aufgabe:**
- Zum Kunden fahren
- Arbeit ausführen (z.B. Wasserhahn reparieren)
- Im System als erledigt markieren

**System-Funktion:**
1. Auftragsübersicht öffnen
2. Nach Status **"Disponiert"** filtern (oder eigenen Namen suchen)
3. Eigenen Auftrag finden
4. **"Ausgeführt"** Button klicken
5. Bestätigung: "Möchten Sie den Status wirklich ändern?"
6. **"OK"** klicken
7. Status ändert sich zu **"ausgefuehrt"**

**Ausgabe:**
- Status: **AUSGEFÜHRT** (grün)
- Auftrag wartet nun auf Freigabe durch Bereichsleiter

---

### Schritt 4: Ausführung überwachen (Bereichsleiter)

**Rolle:** Bereichsleiter

**Aufgabe:**
- Laufende Aufträge im Blick behalten
- Fortschritt kontrollieren
- Bei Problemen eingreifen

**System-Funktion:**

**4a) Übersicht nutzen:**
1. Hauptseite öffnen
2. **Filter** nutzen um verschiedene Status zu sehen:
   - "Disponiert" → zeigt alle zugewiesenen Aufträge
   - "Ausgeführt" → zeigt erledigte, noch nicht freigegebene Aufträge
3. **Statistik** oben rechts zeigt Gesamtanzahl

**4b) Details prüfen:**
1. Bei beliebigem Auftrag auf **"Details"** klicken
2. Modal zeigt alle Informationen:
   - Kundendaten
   - Auftragsbeschreibung
   - Zugewiesener Mitarbeiter
   - Geplanter Termin
   - Aktueller Status
3. Auftragsfortschritt einsehen

**4c) Suchen:**
1. **Suchfeld** nutzen um spezifischen Kunden zu finden
2. Live-Suche während Eingabe

**Screenshot-Referenz:** UI-Mockups.md → "Hauptseite - Auftragsübersicht"

**Wichtig:** 
Dies ist eine **kontinuierliche Überwachungsfunktion** ohne Status-Änderung. Der Bereichsleiter kann jederzeit:
- Sehen wer an was arbeitet
- Prüfen ob Termine eingehalten werden
- Engpässe erkennen
- Bei Bedarf eingreifen

**Ausgabe:**
- Keine Status-Änderung
- Übersicht über alle Aufträge
- Transparenz im Prozess

---

### Schritt 5: Rapport freigeben (Bereichsleiter)

**Rolle:** Bereichsleiter

**Aufgabe:**
- Ausgeführte Aufträge prüfen
- Qualität kontrollieren
- Zur Verrechnung freigeben

**System-Funktion:**
1. Nach Status **"Ausgeführt"** filtern
2. **"Details"** öffnen und Auftrag prüfen
3. Falls OK: **"Freigeben"** Button klicken
4. Bestätigung
5. Status ändert sich zu **"freigegeben"**

**Validierung:**
- Nur Aufträge mit Status "ausgefuehrt" können freigegeben werden
- Sequenzieller Workflow wird erzwungen

**Ausgabe:**
- Status: **FREIGEGEBEN** (lila)
- Auftrag ist bereit zur Verrechnung

---

### Schritt 6: Auftrag verrechnen (Administration)

**Rolle:** Administration

**Aufgabe:**
- Rechnung erstellen
- Auftrag als abgeschlossen markieren

**System-Funktion:**
1. Nach Status **"Freigegeben"** filtern
2. **"Verrechnen"** Button klicken
3. Bestätigung
4. Status ändert sich zu **"verrechnet"**

**Ausgabe:**
- Status: **VERRECHNET** (grau)
- Auftrag ist **abgeschlossen**
- Keine weiteren Aktionen möglich
- Workflow-Ende ✅

---

## 🔐 Berechtigungs-Matrix

| Funktion | Administration | Bereichsleiter | Mitarbeiter |
|----------|----------------|----------------|-------------|
| Auftrag erfassen | ✅ | ✅ | ❌ |
| Auftrag disponieren | ❌ | ✅ | ❌ |
| Als ausgeführt markieren | ❌ | ✅ | ✅ |
| Ausführung überwachen | ❌ | ✅ | ❌ |
| Freigeben | ❌ | ✅ | ❌ |
| Verrechnen | ✅ | ❌ | ❌ |
| Aufträge einsehen | ✅ | ✅ | ✅ (eigene) |
| Drucken | ✅ | ✅ | ✅ |

**Hinweis:** Im aktuellen Prototyp sind keine Login-Rollen implementiert. In der Produktivversion würde dies über ein Benutzer-Management geregelt.

---

## 📈 Status-Übergänge (State Machine)

```
    ┌─────────┐
    │ ERFASST │ ← Schritt 1: Administration erfasst
    └────┬────┘
         │ disponieren
         ↓
  ┌────────────┐
  │ DISPONIERT │ ← Schritt 2: Bereichsleiter disponiert
  └─────┬──────┘
        │ ausführen
        ↓
  ┌────────────┐
  │ AUSGEFÜHRT │ ← Schritt 3: Mitarbeiter führt aus
  └─────┬──────┘   Schritt 4: Bereichsleiter überwacht →
        │ freigeben
        ↓
  ┌────────────┐
  │ FREIGEGEBEN│ ← Schritt 5: Bereichsleiter gibt frei
  └─────┬──────┘
        │ verrechnen
        ↓
  ┌────────────┐
  │ VERRECHNET │ ← Schritt 6: Administration verrechnet
  └────────────┘
       🏁 ENDE
```

**Wichtige Regeln:**
- ❌ Status-Sprünge sind **nicht erlaubt** (z.B. erfasst → verrechnet)
- ✅ Nur **sequenzieller Fortschritt** möglich
- ✅ Wird durch Backend validiert (siehe `api.php`)

---

## 💡 Praktische Beispiele

### Beispiel 1: Standardfall

**Szenario:** Frau Brandenberger ruft an, Wasserhahn tropft

```
10:00 Uhr - Administration nimmt Anruf entgegen
10:05 Uhr - Auftrag im System erfasst
            Status: ERFASST

11:00 Uhr - Bereichsleiter disponiert
            → Peter Müller, Termin: morgen 14:00
            Status: DISPONIERT

Morgen 14:00 - Peter fährt hin, repariert
15:30 Uhr    - Peter markiert als ausgeführt
               Status: AUSGEFÜHRT

15:45 Uhr - Bereichsleiter prüft Details
            → Alles OK, gibt frei
            Status: FREIGEGEBEN

16:00 Uhr - Administration erstellt Rechnung
            → Markiert als verrechnet
            Status: VERRECHNET ✅
```

### Beispiel 2: Mit Überwachung

**Szenario:** Dringender Auftrag, Bereichsleiter überwacht aktiv

```
08:00 Uhr - Dringender Auftrag erfasst
            Status: ERFASST

08:15 Uhr - Sofort disponiert
            → Hans Meier, heute noch
            Status: DISPONIERT

10:00 Uhr - Bereichsleiter prüft Übersicht
            → Filter "Disponiert"
            → Sieht: Hans ist unterwegs
            
12:00 Uhr - Erneute Kontrolle
            → Noch nicht erledigt
            
14:00 Uhr - Kontrolle
            → Status jetzt: AUSGEFÜHRT
            → Hans war erfolgreich
            
14:05 Uhr - Sofort freigegeben
            Status: FREIGEGEBEN

14:10 Uhr - Verrechnet
            Status: VERRECHNET ✅
```

---

## 🎯 Zusammenfassung

### Was wurde umgesetzt:

✅ **Schritt 1** → Button "Neuer Auftrag" + Formular  
✅ **Schritt 2** → Button "Disponieren" + Mitarbeiter/Termin  
✅ **Schritt 3** → Button "Ausgeführt"  
✅ **Schritt 4** → Auftragsübersicht + Filter + Details  
✅ **Schritt 5** → Button "Freigeben"  
✅ **Schritt 6** → Button "Verrechnen"  

### Alle 6 Schritte des internen Ablaufs sind vollständig digital abgebildet! ✅

---

**Version:** 1.0  
**Erstellt:** Januar 2026  
**Status:** Komplett für Projektabgabe
