# Projektdokumentation: Glauser Illnau AG - Auftragsverwaltungssystem

## 1. Ausgangslage

Die Firma Glauser Illnau AG ist ein Sanitärunternehmen, das Neu- und Umbauprojekte sowie Reparatur- und Wartungsarbeiten durchführt. Der aktuelle Prozess erfolgt papierbasiert und soll digitalisiert werden.

### 1.1 Interner Ablauf (gemäß Aufgabenstellung)

Der interne Ablauf für Serviceaufträge umfasst 6 Schritte:

1. **Geschäftsleiter (GL)/Administration**: Auftrag annehmen (i.d.R. telefonisch)
2. **Bereichsleiter (BL)**: Auftrag disponieren/planen (einem Mitarbeiter zuweisen und ev. konkreter Termin festlegen)
3. **Mitarbeiter (MA)**: Auftrag ausführen und rapportieren
4. **Bereichsleiter**: Ausführung administrativ überwachen
5. **Bereichsleiter**: Rapport prüfen und zur Verrechnung freigeben
6. **Administration**: Auftrag verrechnen

Für jeden Auftrag wird bei der Annahme ein Auftragsblatt erstellt, das den ganzen Ablauf begleitet.

## 2. Anforderungsanalyse

### 2.1 Funktionale Anforderungen

Die Webanwendung bildet den kompletten internen Ablauf digital ab:

**Schritt 1 - Auftrag annehmen (Administration):**
- **FA1**: Auftrag erfassen mit Kundendaten und Auftragsbeschreibung
- **FA2**: Auftragsdokument generieren und drucken

**Schritt 2 - Disponieren (Bereichsleiter):**
- **FA4**: Auftrag disponieren (Mitarbeiter zuweisen, Termin festlegen)

**Schritt 3 - Ausführen (Mitarbeiter):**
- **FA5**: Auftrag als ausgeführt markieren

**Schritt 4 - Überwachen (Bereichsleiter):**
- **FA3**: Aufträge nach Zuständen filtern und anzeigen
- **FA7**: Auftragsdetails einsehen und Status überwachen

**Schritt 5 - Freigeben (Bereichsleiter):**
- **FA5**: Auftrag als freigegeben markieren (zur Verrechnung)

**Schritt 6 - Verrechnen (Administration):**
- **FA6**: Auftrag als verrechnet markieren

### 2.2 Nicht-funktionale Anforderungen
- **NFA1**: Responsive Design für Desktop und Tablet
- **NFA2**: Client-seitige Validierung mit JavaScript
- **NFA3**: Benutzerfreundliche Oberfläche
- **NFA4**: Schnelles Feedback bei Benutzeraktionen

### 2.3 Mapping: Interner Ablauf → System-Funktionen

Die folgende Tabelle zeigt, wie jeder Schritt des internen Ablaufs im System umgesetzt wurde:

| Schritt | Rolle | Aufgabe | System-Funktion | Status-Änderung |
|---------|-------|---------|-----------------|-----------------|
| 1 | Administration | Auftrag annehmen | "Neuer Auftrag" Button → Formular ausfüllen → Speichern | → **erfasst** |
| 2 | Bereichsleiter | Disponieren/Planen | "Disponieren" Button → Mitarbeiter + Termin wählen | erfasst → **disponiert** |
| 3 | Mitarbeiter | Ausführen & Rapportieren | "Ausgeführt" Button klicken | disponiert → **ausgefuehrt** |
| 4 | Bereichsleiter | Administrativ überwachen | Auftragsübersicht + Filter + Details-Ansicht | (kein Status-Wechsel) |
| 5 | Bereichsleiter | Rapport prüfen & freigeben | "Freigeben" Button klicken | ausgefuehrt → **freigegeben** |
| 6 | Administration | Verrechnen | "Verrechnen" Button klicken | freigegeben → **verrechnet** |

**Wichtig:** Die Überwachungsfunktion (Schritt 4) ist kontinuierlich durch die Auftragsübersicht verfügbar, wo der Bereichsleiter:
- Alle laufenden Aufträge sehen kann
- Nach Status filtern kann (z.B. nur "disponiert" anzeigen)
- Details jedes Auftrags einsehen kann
- Den Fortschritt überwachen kann

## 3. Architektur und Technologien

### 3.1 Technologie-Stack
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Backend**: PHP 7.4+
- **Datenbank**: MySQL 8.0
- **Webserver**: Apache

### 3.2 Architektur
- **Muster**: MVC (Model-View-Controller)
- **Schichten**:
  - Präsentationsschicht (HTML/CSS/JS)
  - Logikschicht (PHP)
  - Datenschicht (MySQL)

### 3.3 Schnittstellen
- REST-ähnliche API für AJAX-Aufrufe
- JSON als Datenformat für Client-Server Kommunikation

## 4. Use Case Diagramm

```
                    Glauser Illnau AG - Auftragsverwaltung
                    
    +------------------+
    | Administration   |
    +------------------+
            |
            |--- (Auftrag erfassen)
            |--- (Auftragsdokument drucken)
            |--- (Auftrag verrechnen)
            |
    +------------------+
    | Bereichsleiter   |
    +------------------+
            |
            |--- (Auftrag disponieren)
            |--- (Aufträge überwachen)
            |--- (Rapport freigeben)
            |--- (Auftragsliste einsehen)
            |
    +------------------+
    | Mitarbeiter      |
    +------------------+
            |
            |--- (Auftrag als ausgeführt markieren)
            |--- (Eigene Aufträge einsehen)
```

## 5. Klassendiagramm

```
+-------------------+
| Auftrag           |
+-------------------+
| - id: int         |
| - datum: date     |
| - zeit: time      |
| - kunde_id: int   |
| - objekt_adr: str |
| - verr_adr: str   |
| - arbeiten: arr   |
| - beschreibung:str|
| - termin_wunsch:st|
| - status: enum    |
| - ma_id: int      |
| - termin: date    |
+-------------------+
| + erstellen()     |
| + disponieren()   |
| + ausfuehren()    |
| + freigeben()     |
| + verrechnen()    |
+-------------------+
         |
         | 1:n
         |
+-------------------+
| Kunde             |
+-------------------+
| - id: int         |
| - name: string    |
| - adresse: string |
| - plz: string     |
| - ort: string     |
| - telefon: string |
| - natel: string   |
+-------------------+
| + speichern()     |
| + laden()         |
+-------------------+

+-------------------+
| Mitarbeiter       |
+-------------------+
| - id: int         |
| - name: string    |
| - rolle: enum     |
+-------------------+
| + laden()         |
+-------------------+
```

## 6. Datenmodell

### 6.1 Entity-Relationship-Diagramm (ERD)

```
    KUNDE ----------< AUFTRAG >---------- MITARBEITER
    (1,n)              (1,1)              (0,1)
    
    Attribute Kunde:
    - kunde_id (PK)
    - name
    - adresse
    - plz
    - ort
    - telefon
    - natel
    
    Attribute Auftrag:
    - auftrag_id (PK)
    - datum
    - zeit
    - kunde_id (FK)
    - objekt_adresse
    - verrechnung_adresse
    - arbeiten_reparatur
    - arbeiten_sanitaer
    - arbeiten_heizung
    - arbeiten_garantie
    - beschreibung
    - termin_wunsch
    - status
    - mitarbeiter_id (FK)
    - termin
    - erstellt_am
    - aktualisiert_am
    
    Attribute Mitarbeiter:
    - mitarbeiter_id (PK)
    - name
    - rolle
```

### 6.2 Datentypen und Wertebereiche

**Tabelle: kunde**
- kunde_id: INT, AUTO_INCREMENT, PRIMARY KEY
- name: VARCHAR(255), NOT NULL
- adresse: VARCHAR(255), NOT NULL
- plz: VARCHAR(10), NOT NULL
- ort: VARCHAR(100), NOT NULL
- telefon: VARCHAR(20)
- natel: VARCHAR(20)

**Tabelle: auftrag**
- auftrag_id: INT, AUTO_INCREMENT, PRIMARY KEY
- datum: DATE, NOT NULL
- zeit: TIME, NOT NULL
- kunde_id: INT, FOREIGN KEY, NOT NULL
- objekt_adresse: VARCHAR(255)
- verrechnung_adresse: VARCHAR(255)
- arbeiten_reparatur: BOOLEAN, DEFAULT FALSE
- arbeiten_sanitaer: BOOLEAN, DEFAULT FALSE
- arbeiten_heizung: BOOLEAN, DEFAULT FALSE
- arbeiten_garantie: BOOLEAN, DEFAULT FALSE
- beschreibung: TEXT, NOT NULL
- termin_wunsch: VARCHAR(100)
- status: ENUM('erfasst', 'disponiert', 'ausgefuehrt', 'freigegeben', 'verrechnet'), DEFAULT 'erfasst'
- mitarbeiter_id: INT, FOREIGN KEY, NULL
- termin: DATE, NULL
- erstellt_am: TIMESTAMP, DEFAULT CURRENT_TIMESTAMP
- aktualisiert_am: TIMESTAMP, DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP

**Tabelle: mitarbeiter**
- mitarbeiter_id: INT, AUTO_INCREMENT, PRIMARY KEY
- name: VARCHAR(255), NOT NULL
- rolle: ENUM('administration', 'bereichsleiter', 'mitarbeiter'), NOT NULL

## 7. UI-Skizzen

### 7.1 Hauptseite - Auftragsübersicht
```
+------------------------------------------------------------------+
| GLAUSER ILLNAU AG - Auftragsverwaltung                          |
+------------------------------------------------------------------+
| [Neuer Auftrag]  [Filter: Alle ▼]                              |
+------------------------------------------------------------------+
| Nr.  | Datum      | Kunde           | Status      | Aktion      |
|------|------------|-----------------|-------------|-------------|
| 1234 | 23.09.2014 | B. Brandenberg  | Erfasst     | [Details]   |
| 1235 | 24.09.2014 | M. Müller       | Disponiert  | [Details]   |
+------------------------------------------------------------------+
```

### 7.2 Auftrag erfassen
```
+------------------------------------------------------------------+
| Neuer Serviceauftrag                                            |
+------------------------------------------------------------------+
| Datum: [23.09.2014]  Zeit: [10:00]                             |
|                                                                  |
| KUNDE/KONTAKTPERSON                                             |
| Name: [_____________________]                                   |
| Adresse: [__________________]                                   |
| PLZ: [____] Ort: [_________]                                   |
| Telefon: [_______________]  Natel: [_______________]           |
|                                                                  |
| OBJEKTADRESSE                                                    |
| [x] Gleich wie Kundenadresse  [ ] Andere: [_______________]    |
|                                                                  |
| VERRECHNUNGSADRESSE                                             |
| [x] Gleich wie Kundenadresse  [ ] Andere: [_______________]    |
|                                                                  |
| AUSZUFÜHRENDE ARBEITEN                                          |
| [x] Reparatur  [x] Sanitär  [ ] Heizung  [ ] Garantie         |
|                                                                  |
| BESCHREIBUNG                                                     |
| [________________________________________________]               |
| [________________________________________________]               |
|                                                                  |
| TERMINWUNSCH                                                     |
| [so schnell wie möglich________________________]               |
|                                                                  |
|                              [Abbrechen]  [Speichern]          |
+------------------------------------------------------------------+
```

## 8. Testkonzept

### 8.1 Unit Tests
- **UT1**: Validierung Kundendaten (PLZ Format, Telefonnummer)
- **UT2**: Validierung Auftragsdaten (Datum, Zeit, Beschreibung)
- **UT3**: Status-Übergänge (erfasst → disponiert → ausgeführt → freigegeben → verrechnet)

### 8.2 Integrationstests
- **IT1**: Auftrag erfassen und in Datenbank speichern
- **IT2**: Auftrag disponieren und Mitarbeiter zuweisen
- **IT3**: Auftragsdokument generieren

### 8.3 System-Tests
- **ST1**: Kompletter Workflow von Erfassung bis Verrechnung
- **ST2**: Filterung und Sortierung der Auftragsliste
- **ST3**: PDF-Generierung und Druck

### 8.4 Testdaten
- Mindestens 10 Testaufträge in verschiedenen Status
- 5 Testkunden
- 3 Testmitarbeiter (je einer pro Rolle)

## 9. Implementierung

### 9.1 Entwicklungsschritte
1. Datenbank erstellen und Testdaten einfügen
2. UI Mockup erstellen (HTML/CSS)
3. Backend API implementieren (PHP)
4. JavaScript-Logik implementieren
5. Tests durchführen
6. Dokumentation vervollständigen

### 9.2 Zeitplan (geschätzt)
- Analyse und Entwurf: 4 Stunden
- Datenbank: 2 Stunden
- UI Mockup: 4 Stunden
- Backend: 8 Stunden
- Frontend JS: 6 Stunden
- Tests: 4 Stunden
- **Total: ca. 28 Stunden**

## 10. Risiken und Herausforderungen

- **R1**: Komplexität der Status-Übergänge → Lösung: Klare State-Machine
- **R2**: PDF-Generierung → Lösung: Einfache HTML-basierte Lösung
- **R3**: Datenvalidierung → Lösung: Doppelte Validierung (Client + Server)

## 11. Erweiterungsmöglichkeiten

- Benutzer-Login und Authentifizierung
- E-Mail-Benachrichtigungen bei Statusänderungen
- Zeiterfassung und Material-Rapportierung
- Dashboard mit Statistiken
- Mobile App
