# UI Mockups - Glauser Illnau AG Auftragsverwaltung

## 📱 Benutzeroberfläche - Wireframes und Mockups

---

## 1. Hauptseite - Auftragsübersicht

### Layout-Beschreibung

```
╔════════════════════════════════════════════════════════════════════╗
║  GLAUSER ILLNAU AG                        [+ Neuer Auftrag]       ║
║  Auftragsverwaltungssystem                                         ║
╠════════════════════════════════════════════════════════════════════╣
║                                                                     ║
║  Status: [Alle ▼]  🔍 [Suche nach Kunde...]    Gesamt: 8         ║
║                                                                     ║
╠════════════════════════════════════════════════════════════════════╣
║ Nr.  │ Datum      │ Zeit  │ Kunde              │ Status      │... ║
╟──────┼────────────┼───────┼────────────────────┼─────────────┼────╢
║ 1234 │ 23.09.2024 │ 10:00 │ B. Brandenberger  │ [Erfasst]   │ >> ║
║ 1235 │ 24.09.2024 │ 14:30 │ R. Rutishauser    │ [Disponiert]│ >> ║
║ 1236 │ 25.09.2024 │ 09:15 │ Familie Meier     │ [Ausgeführt]│ >> ║
║ 1237 │ 26.09.2024 │ 11:00 │ Gemeinde Illnau   │ [Freigeben] │ >> ║
║ 1238 │ 27.09.2024 │ 15:45 │ Restaurant Löwen  │ [Verrechnet]│ >> ║
║ 1239 │ 28.09.2024 │ 08:30 │ B. Brandenberger  │ [Erfasst]   │ >> ║
╚════════════════════════════════════════════════════════════════════╝
```

### Farbschema
- **Header**: Gradient Türkis (#0d9488 → #14b8a6)
- **Toolbar**: Weiß mit Schatten
- **Tabelle**: Zebra-Streifen (Weiß / Hellgrau)
- **Status-Badges**: Farbcodiert (siehe unten)

### Interaktive Elemente
1. **Neuer Auftrag Button**: Öffnet Modal
2. **Filter Dropdown**: Filtert nach Status
3. **Suchfeld**: Live-Suche während Eingabe
4. **Tabellen-Zeilen**: Hover-Effekt (grüner Hintergrund)
5. **Action Buttons**: Details, Disponieren, Status ändern

---

## 2. Modal - Neuer Auftrag

### Layout-Beschreibung

```
╔═══════════════════════════════════════════════════════════════╗
║  Neuer Serviceauftrag                                    [✕]  ║
╠═══════════════════════════════════════════════════════════════╣
║                                                                ║
║  Datum: [23.09.2024▼]      Zeit: [10:00 ⌚]                   ║
║                                                                ║
║  ─────────── KUNDE / KONTAKTPERSON ───────────                ║
║                                                                ║
║  Name: *                                                       ║
║  [_______________________________________________________]     ║
║                                                                ║
║  Adresse: *                                                    ║
║  [_______________________________________________________]     ║
║                                                                ║
║  PLZ: *          Ort: *                                       ║
║  [____]          [___________________]                        ║
║                                                                ║
║  Telefon:        Natel:                                       ║
║  [____________]  [____________]                               ║
║                                                                ║
║  ─────────── ADRESSE OBJEKT ───────────                       ║
║                                                                ║
║  ☑ Gleich wie Kundenadresse                                   ║
║  ☐ Andere: [_________________________________________]         ║
║                                                                ║
║  ─────────── ADRESSE VERRECHNUNG ───────────                  ║
║                                                                ║
║  ☑ Gleich wie Kundenadresse                                   ║
║  ☐ Andere: [_________________________________________]         ║
║                                                                ║
║  ─────────── AUSZUFÜHRENDE ARBEITEN ───────────               ║
║                                                                ║
║  ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐    ║
║  │☑ Reparatur│ │☑ Sanitär  │ │☐ Heizung  │ │☐ Garantie │    ║
║  └───────────┘ └───────────┘ └───────────┘ └───────────┘    ║
║                                                                ║
║  Beschreibung: *                                              ║
║  ┌──────────────────────────────────────────────────────┐    ║
║  │ Wasserhahn in der Küche tropft/undicht.             │    ║
║  │                                                       │    ║
║  │                                                       │    ║
║  └──────────────────────────────────────────────────────┘    ║
║                                                                ║
║  Terminwunsch:                                                ║
║  [so schnell wie möglich_____________________________]        ║
║                                                                ║
║                                   [Abbrechen] [Speichern]     ║
╚═══════════════════════════════════════════════════════════════╝
```

### Design-Details
- **Backdrop**: Blur-Effekt auf Hintergrund
- **Modal**: Abgerundete Ecken, Schatten
- **Pflichtfelder**: Mit * markiert
- **Checkboxen**: Als Cards mit Hover-Effekt
- **Buttons**: Gradient (Speichern), Weiß (Abbrechen)

---

## 3. Modal - Auftrag Details

### Layout-Beschreibung

```
╔═══════════════════════════════════════════════════════════════╗
║  Auftrag Nr. 1234                                        [✕]  ║
╠═══════════════════════════════════════════════════════════════╣
║                                                                ║
║  ┌─────────────────┐  ┌─────────────────┐                    ║
║  │ DATUM           │  │ ZEIT            │                    ║
║  │ 23.09.2024      │  │ 10:00 Uhr       │                    ║
║  └─────────────────┘  └─────────────────┘                    ║
║                                                                ║
║  ┌─────────────────┐  ┌─────────────────┐                    ║
║  │ STATUS          │  │ ERSTELLT AM     │                    ║
║  │ [Erfasst]       │  │ 23.09.24 10:05  │                    ║
║  └─────────────────┘  └─────────────────┘                    ║
║                                                                ║
║  ─────────── KUNDE ───────────                                ║
║                                                                ║
║  ┌────────────────────────────────────────────────────────┐  ║
║  │ NAME                                                    │  ║
║  │ Frau Beatrice Brandenberger                            │  ║
║  └────────────────────────────────────────────────────────┘  ║
║                                                                ║
║  ┌────────────────────────────────────────────────────────┐  ║
║  │ ADRESSE                                                 │  ║
║  │ Obderdorfstrasse 11                                    │  ║
║  └────────────────────────────────────────────────────────┘  ║
║                                                                ║
║  ┌─────────────────┐  ┌─────────────────┐                    ║
║  │ TELEFON         │  │ NATEL           │                    ║
║  │ 098 765 43 21   │  │ 079 797 97 97   │                    ║
║  └─────────────────┘  └─────────────────┘                    ║
║                                                                ║
║  ─────────── AUFTRAG ───────────                              ║
║                                                                ║
║  ┌────────────────────────────────────────────────────────┐  ║
║  │ AUSZUFÜHRENDE ARBEITEN                                  │  ║
║  │ Reparatur, Sanitär                                      │  ║
║  └────────────────────────────────────────────────────────┘  ║
║                                                                ║
║  ┌────────────────────────────────────────────────────────┐  ║
║  │ BESCHREIBUNG                                            │  ║
║  │ Wasserhahn in der Küche tropft/undicht.               │  ║
║  └────────────────────────────────────────────────────────┘  ║
║                                                                ║
║                            [Schließen] [Auftrag drucken]      ║
╚═══════════════════════════════════════════════════════════════╝
```

---

## 4. Modal - Disponieren

### Layout-Beschreibung

```
╔════════════════════════════════════════════╗
║  Auftrag disponieren                  [✕] ║
╠════════════════════════════════════════════╣
║                                             ║
║  Mitarbeiter zuweisen: *                   ║
║  ┌─────────────────────────────────────┐  ║
║  │ -- Bitte wählen --              ▼  │  ║
║  ├─────────────────────────────────────┤  ║
║  │ Thomas Weber (Bereichsleiter)       │  ║
║  │ Peter Müller (Mitarbeiter)          │  ║
║  │ Hans Meier (Mitarbeiter)            │  ║
║  │ Sandra Keller (Mitarbeiter)         │  ║
║  └─────────────────────────────────────┘  ║
║                                             ║
║  Termin: *                                 ║
║  [26.09.2024 📅]                           ║
║                                             ║
║                                             ║
║              [Abbrechen] [Disponieren]     ║
╚════════════════════════════════════════════╝
```

---

## 5. Druckansicht - Serviceauftrag

### Layout-Beschreibung

```
┌─────────────────────────────────────────────────────────────┐
│                                                              │
│                     SERVICEAUFTRAG                          │
│                  Glauser Illnau AG                          │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Datum: 23.09.2024            Auftrag Nr.: 1234             │
│  Zeit:  10:00 Uhr                                           │
│                                                              │
│  KUNDE / KONTAKTPERSON:                                     │
│  ─────────────────────────────                              │
│  Frau Beatrice Brandenberger                                │
│  Obderdorfstrasse 11                                        │
│  8484 Weisslingen                                           │
│                                                              │
│  Telefon: 098 765 43 21                                     │
│  Natel:   079 797 97 97                                     │
│                                                              │
│  ADRESSE OBJEKT:                                            │
│  ─────────────────────                                      │
│  dito                                                        │
│                                                              │
│  ADRESSE VERRECHNUNG:                                       │
│  ────────────────────────                                   │
│  dito                                                        │
│                                                              │
│  AUSZUFÜHRENDE ARBEITEN:                                    │
│  ───────────────────────────                                │
│  ☑ Reparatur    ☑ Sanitär                                  │
│  ☐ Heizung      ☐ Garantie                                 │
│                                                              │
│  BESCHREIBUNG:                                              │
│  ─────────────────                                          │
│  Wasserhahn in der Küche tropft/undicht.                   │
│                                                              │
│                                                              │
│  TERMINWUNSCH:                                              │
│  ─────────────────                                          │
│  so schnell wie möglich                                     │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│         Glauser Illnau AG | Sanitärunternehmen              │
│         Gedruckt am 23.09.2024 10:05 Uhr                   │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Responsive Design - Mobile Ansicht

### Smartphone (375px)

```
┌─────────────────────┐
│ ☰  GLAUSER ILLNAU  │
│    [+ Neu]          │
├─────────────────────┤
│ Status: [Alle ▼]   │
│ 🔍 [Suche...]      │
├─────────────────────┤
│                     │
│ ┌─────────────────┐│
│ │ #1234           ││
│ │ B. Brandenberg  ││
│ │ 23.09. | 10:00  ││
│ │ [Erfasst]       ││
│ │ [Details >>]    ││
│ └─────────────────┘│
│                     │
│ ┌─────────────────┐│
│ │ #1235           ││
│ │ R. Rutishauser  ││
│ │ 24.09. | 14:30  ││
│ │ [Disponiert]    ││
│ │ [Details >>]    ││
│ └─────────────────┘│
│                     │
└─────────────────────┘
```

---

## 7. Farbpalette und Typografie

### Farben

**Primärfarben:**
- Türkis: `#0d9488` (Hauptfarbe)
- Türkis Hell: `#14b8a6` (Gradient)
- Türkis Dunkel: `#0f766e` (Hover)

**Status-Farben:**
- Erfasst: `#3b82f6` (Blau)
- Disponiert: `#f59e0b` (Gelb/Orange)
- Ausgeführt: `#10b981` (Grün)
- Freigegeben: `#a855f7` (Lila)
- Verrechnet: `#6b7280` (Grau)

**Neutrale Farben:**
- Hintergrund: `#f8fafc`
- Cards: `#ffffff`
- Text: `#0f172a`
- Text Sekundär: `#64748b`
- Border: `#e2e8f0`

### Typografie

**Schriftart:** Inter, System Fonts
**Größen:**
- H1 (Header): 32px, Bold
- H2 (Modale): 22px, ExtraBold
- H3 (Sektionen): 15px, Bold
- Body: 14px, Regular
- Small: 12px, Regular

---

## 8. Design-Patterns

### Cards
```
┌─────────────────────────────────┐
│  TITEL (Bold, Uppercase)        │
│  ─────────────────              │
│  Inhalt (Regular)               │
│  Wert (Medium, größer)          │
└─────────────────────────────────┘
```

### Buttons
```
┌──────────────┐    ┌──────────────┐
│   PRIMARY    │    │  SECONDARY   │
│  (Gradient)  │    │   (Weiß)     │
└──────────────┘    └──────────────┘
```

### Status-Badges
```
( ● Erfasst )  Pill-Form mit Dot-Indicator
```

---

## 9. Interaktions-Flows

### Flow 1: Neuen Auftrag erstellen
```
Hauptseite → [+ Neuer Auftrag] → Modal öffnet
          → Formular ausfüllen
          → [Speichern]
          → Toast-Nachricht: "Erfolgreich!"
          → Modal schließt
          → Liste aktualisiert
```

### Flow 2: Auftrag disponieren
```
Hauptseite → [Disponieren] Button → Modal öffnet
          → Mitarbeiter wählen
          → Termin setzen
          → [Disponieren]
          → Toast: "Disponiert!"
          → Status ändert zu "Disponiert"
```

### Flow 3: Status ändern
```
Hauptseite → [Ausgeführt] Button → Bestätigung
          → OK
          → Status ändert
          → Toast: "Status geändert!"
```

---

## 10. Accessibility (Barrierefreiheit)

- ✅ Kontrast-Verhältnis > 4.5:1
- ✅ Fokus-Indikatoren sichtbar
- ✅ Tastatur-Navigation möglich
- ✅ Labels für Formular-Felder
- ✅ Fehler-Meldungen klar beschriftet
- ✅ Status durch Farbe UND Text

---

**Version**: 1.0  
**Tools**: ASCII Art, Mockup-Beschreibung  
**Status**: Final für Projektabgabe
