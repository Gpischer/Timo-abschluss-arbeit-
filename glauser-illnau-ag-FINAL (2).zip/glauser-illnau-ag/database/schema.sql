-- =====================================================
-- Glauser Illnau AG - Datenbank Schema
-- =====================================================
-- Erstellt für: Projektarbeit Applikationsentwicklung
-- Datum: Januar 2026
-- =====================================================

-- Datenbank erstellen
DROP DATABASE IF EXISTS glauser_illnau_ag;
CREATE DATABASE glauser_illnau_ag CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE glauser_illnau_ag;

-- =====================================================
-- Tabelle: mitarbeiter
-- =====================================================
CREATE TABLE mitarbeiter (
    mitarbeiter_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    rolle ENUM('administration', 'bereichsleiter', 'mitarbeiter') NOT NULL,
    erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_rolle (rolle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Tabelle: kunde
-- =====================================================
CREATE TABLE kunde (
    kunde_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    adresse VARCHAR(255) NOT NULL,
    plz VARCHAR(10) NOT NULL,
    ort VARCHAR(100) NOT NULL,
    telefon VARCHAR(20),
    natel VARCHAR(20),
    erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    aktualisiert_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_ort (ort)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Tabelle: auftrag
-- =====================================================
CREATE TABLE auftrag (
    auftrag_id INT AUTO_INCREMENT PRIMARY KEY,
    datum DATE NOT NULL,
    zeit TIME NOT NULL,
    kunde_id INT NOT NULL,
    objekt_adresse VARCHAR(255),
    verrechnung_adresse VARCHAR(255),
    arbeiten_reparatur BOOLEAN DEFAULT FALSE,
    arbeiten_sanitaer BOOLEAN DEFAULT FALSE,
    arbeiten_heizung BOOLEAN DEFAULT FALSE,
    arbeiten_garantie BOOLEAN DEFAULT FALSE,
    beschreibung TEXT NOT NULL,
    termin_wunsch VARCHAR(100),
    status ENUM('erfasst', 'disponiert', 'ausgefuehrt', 'freigegeben', 'verrechnet') DEFAULT 'erfasst',
    mitarbeiter_id INT NULL,
    termin DATE NULL,
    erstellt_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    aktualisiert_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kunde_id) REFERENCES kunde(kunde_id) ON DELETE RESTRICT,
    FOREIGN KEY (mitarbeiter_id) REFERENCES mitarbeiter(mitarbeiter_id) ON DELETE SET NULL,
    INDEX idx_datum (datum),
    INDEX idx_status (status),
    INDEX idx_kunde (kunde_id),
    INDEX idx_mitarbeiter (mitarbeiter_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Testdaten einfügen
-- =====================================================

-- Mitarbeiter
INSERT INTO mitarbeiter (name, rolle) VALUES 
('Maria Schmidt', 'administration'),
('Thomas Weber', 'bereichsleiter'),
('Peter Müller', 'mitarbeiter'),
('Hans Meier', 'mitarbeiter'),
('Sandra Keller', 'mitarbeiter');

-- Kunden
INSERT INTO kunde (name, adresse, plz, ort, telefon, natel) VALUES 
('Frau Beatrice Brandenberger', 'Obderdorfstrasse 11', '8484', 'Weisslingen', '098 765 43 21', '079 797 97 97'),
('Herr Rudd Rutishauser', 'Unterdorfstrasse 22', '8484', 'Weisslingen', '052 123 45 67', '079 111 22 33'),
('Familie Meier', 'Hauptstrasse 45', '8340', 'Hinwil', '044 937 11 22', '078 999 88 77'),
('Gemeinde Illnau', 'Dorfstrasse 1', '8308', 'Illnau', '052 345 67 89', NULL),
('Restaurant Löwen', 'Bahnhofstrasse 12', '8340', 'Hinwil', '044 937 22 33', '079 555 44 33');

-- Aufträge mit verschiedenen Status
INSERT INTO auftrag (
    datum, zeit, kunde_id, objekt_adresse, verrechnung_adresse,
    arbeiten_reparatur, arbeiten_sanitaer, arbeiten_heizung, arbeiten_garantie,
    beschreibung, termin_wunsch, status, mitarbeiter_id, termin
) VALUES 
(
    '2024-09-23', '10:00:00', 1, 'dito', 'dito',
    TRUE, TRUE, FALSE, FALSE,
    'Wasserhahn in der Küche tropft/undicht.',
    'so schnell wie möglich',
    'erfasst', NULL, NULL
),
(
    '2024-09-24', '14:30:00', 2, 'dito', 'dito',
    TRUE, FALSE, FALSE, FALSE,
    'WC-Spülung läuft ständig nach. Muss repariert werden.',
    'diese Woche',
    'disponiert', 3, '2024-09-26'
),
(
    '2024-09-25', '09:15:00', 3, 'dito', 'dito',
    FALSE, TRUE, FALSE, FALSE,
    'Neue Armatur im Badezimmer installieren. Material liegt bereit.',
    'nach Vereinbarung',
    'ausgefuehrt', 4, '2024-09-27'
),
(
    '2024-09-26', '11:00:00', 4, 'Turnhalle, Schulstrasse 5, 8308 Illnau', 'dito',
    TRUE, FALSE, TRUE, FALSE,
    'Heizung in Turnhalle funktioniert nicht. Dringender Auftrag!',
    'sofort',
    'freigegeben', 3, '2024-09-26'
),
(
    '2024-09-27', '15:45:00', 5, 'dito', 'dito',
    FALSE, TRUE, FALSE, FALSE,
    'Verstopfte Abflussleitung in Küche. Gastronomie betroffen.',
    'heute noch',
    'verrechnet', 4, '2024-09-27'
),
(
    '2024-09-28', '08:30:00', 1, 'dito', 'dito',
    FALSE, FALSE, TRUE, FALSE,
    'Heizung macht Geräusche. Wartung durchführen.',
    'nächste Woche',
    'erfasst', NULL, NULL
),
(
    '2024-09-29', '13:00:00', 2, 'dito', 'dito',
    TRUE, TRUE, FALSE, FALSE,
    'Wasserschaden im Keller. Rohrbruch vermutet.',
    'dringend',
    'disponiert', 3, '2024-09-30'
),
(
    '2024-09-30', '10:30:00', 3, 'dito', 'dito',
    FALSE, FALSE, FALSE, TRUE,
    'Garantiefall: Nachbesserung an kürzlich installierter Dusche.',
    'nach Vereinbarung',
    'erfasst', NULL, NULL
);

-- =====================================================
-- Views für Reports
-- =====================================================

-- View: Offene Aufträge
CREATE VIEW v_offene_auftraege AS
SELECT 
    a.auftrag_id,
    a.datum,
    a.zeit,
    k.name AS kunde_name,
    a.beschreibung,
    a.status,
    m.name AS mitarbeiter_name,
    a.termin
FROM auftrag a
INNER JOIN kunde k ON a.kunde_id = k.kunde_id
LEFT JOIN mitarbeiter m ON a.mitarbeiter_id = m.mitarbeiter_id
WHERE a.status IN ('erfasst', 'disponiert', 'ausgefuehrt', 'freigegeben')
ORDER BY 
    CASE a.status
        WHEN 'erfasst' THEN 1
        WHEN 'disponiert' THEN 2
        WHEN 'ausgefuehrt' THEN 3
        WHEN 'freigegeben' THEN 4
    END,
    a.datum DESC;

-- View: Statistik nach Status
CREATE VIEW v_auftraege_statistik AS
SELECT 
    status,
    COUNT(*) AS anzahl,
    DATE_FORMAT(MIN(datum), '%d.%m.%Y') AS aeltester_auftrag,
    DATE_FORMAT(MAX(datum), '%d.%m.%Y') AS neuester_auftrag
FROM auftrag
GROUP BY status;

-- =====================================================
-- Stored Procedures
-- =====================================================

DELIMITER //

-- Procedure: Auftrag disponieren
CREATE PROCEDURE sp_auftrag_disponieren(
    IN p_auftrag_id INT,
    IN p_mitarbeiter_id INT,
    IN p_termin DATE
)
BEGIN
    UPDATE auftrag
    SET 
        status = 'disponiert',
        mitarbeiter_id = p_mitarbeiter_id,
        termin = p_termin
    WHERE auftrag_id = p_auftrag_id
    AND status = 'erfasst';
    
    SELECT ROW_COUNT() AS affected_rows;
END //

-- Procedure: Status ändern
CREATE PROCEDURE sp_status_aendern(
    IN p_auftrag_id INT,
    IN p_neuer_status ENUM('erfasst', 'disponiert', 'ausgefuehrt', 'freigegeben', 'verrechnet')
)
BEGIN
    DECLARE v_aktueller_status VARCHAR(20);
    
    SELECT status INTO v_aktueller_status
    FROM auftrag
    WHERE auftrag_id = p_auftrag_id;
    
    -- Validierung der Status-Übergänge
    IF (v_aktueller_status = 'erfasst' AND p_neuer_status IN ('disponiert')) OR
       (v_aktueller_status = 'disponiert' AND p_neuer_status IN ('ausgefuehrt')) OR
       (v_aktueller_status = 'ausgefuehrt' AND p_neuer_status IN ('freigegeben')) OR
       (v_aktueller_status = 'freigegeben' AND p_neuer_status IN ('verrechnet')) THEN
        
        UPDATE auftrag
        SET status = p_neuer_status
        WHERE auftrag_id = p_auftrag_id;
        
        SELECT 1 AS success, 'Status erfolgreich geändert' AS message;
    ELSE
        SELECT 0 AS success, 'Ungültiger Status-Übergang' AS message;
    END IF;
END //

DELIMITER ;

-- =====================================================
-- Trigger
-- =====================================================

DELIMITER //

-- Trigger: Log bei Statusänderung
CREATE TABLE auftrag_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    auftrag_id INT NOT NULL,
    alter_status VARCHAR(20),
    neuer_status VARCHAR(20),
    geaendert_am TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_auftrag (auftrag_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TRIGGER tr_auftrag_status_log
AFTER UPDATE ON auftrag
FOR EACH ROW
BEGIN
    IF OLD.status != NEW.status THEN
        INSERT INTO auftrag_log (auftrag_id, alter_status, neuer_status)
        VALUES (NEW.auftrag_id, OLD.status, NEW.status);
    END IF;
END //

DELIMITER ;

-- =====================================================
-- Berechtigungen (Beispiel)
-- =====================================================
-- CREATE USER 'glauser_app'@'localhost' IDENTIFIED BY 'SecurePassword123!';
-- GRANT SELECT, INSERT, UPDATE ON glauser_illnau_ag.* TO 'glauser_app'@'localhost';
-- FLUSH PRIVILEGES;

-- =====================================================
-- Ende des Scripts
-- =====================================================
