# 📦 INSTALLATION - Glauser Serviceauftrag Management

Komplette Schritt-für-Schritt Anleitung zur Installation des Systems.

---

## 📋 VORAUSSETZUNGEN

### Software (MUSS installiert sein):

1. **XAMPP 8.2+** - https://www.apachefriends.org/
2. **Node.js 18+** - https://nodejs.org/
3. **Git** (optional) - https://git-scm.com/
4. **Browser** - Chrome, Firefox, oder Edge

### System:
- Windows 10/11, macOS, oder Linux
- 8 GB RAM (minimum)
- 1 GB freier Speicher

---

## 🚀 SCHNELLSTART (15 Minuten)

```bash
# 1. Projekt entpacken
# 2. XAMPP starten (Apache + MySQL)
# 3. Datenbank importieren
# 4. Backend starten: php -S localhost:8000
# 5. Frontend starten: npm install && npm start
# 6. Login: admin / admin123
```

---

## 📝 DETAILLIERTE INSTALLATION

### SCHRITT 1: PROJEKT ENTPACKEN (1 Minute)

1. **ZIP-Datei entpacken:**
   - Rechtsklick auf `glauser-serviceauftrag.zip`
   - "Entpacken nach..." wählen
   - Empfohlener Pfad: `C:\xampp\htdocs\glauser-serviceauftrag`

2. **Ordner-Struktur prüfen:**
   ```
   glauser-serviceauftrag/
   ├── backend/
   ├── frontend/
   ├── database/
   └── dokumentation/
   ```

---

### SCHRITT 2: XAMPP INSTALLIEREN & STARTEN (5 Minuten)

#### Installation:

1. **Download XAMPP:**
   - Windows: https://www.apachefriends.org/download.html
   - Version: XAMPP 8.2 oder höher

2. **Installieren:**
   - Installer ausführen
   - Installation in: `C:\xampp` (Standard)
   - Alle Komponenten auswählen
   - Installation abschließen

3. **XAMPP Control Panel öffnen:**
   - Start → "XAMPP Control Panel"
   - Als Administrator ausführen

#### XAMPP starten:

1. **Apache starten:**
   - Klick auf "Start" bei Apache
   - Warte bis "Running" grün angezeigt wird
   - Port 80 sollte frei sein

2. **MySQL starten:**
   - Klick auf "Start" bei MySQL
   - Warte bis "Running" grün angezeigt wird
   - Port 3306 sollte frei sein

**Kontrolle:**
```
✅ Apache: Running (grün)
✅ MySQL: Running (grün)
```

**Probleme?**

**Port 80 belegt (Apache startet nicht):**
- Skype schließen (nutzt Port 80)
- IIS deaktivieren (Windows Feature)
- Oder Apache-Port ändern in `C:\xampp\apache\conf\httpd.conf`

**Port 3306 belegt (MySQL startet nicht):**
- Andere MySQL-Installation stoppen
- Oder MySQL-Port ändern in `C:\xampp\mysql\bin\my.ini`

---

### SCHRITT 3: DATENBANK ERSTELLEN (3 Minuten)

#### phpMyAdmin öffnen:

1. **Browser öffnen:**
   ```
   http://localhost/phpmyadmin
   ```

2. **Sollte sich öffnen ohne Login** (Standard XAMPP)

#### Datenbank erstellen:

1. **Klick auf "Neu"** (links in der Sidebar)

2. **Datenbank-Name eingeben:**
   ```
   glauser_serviceauftrag
   ```

3. **Zeichensatz wählen:**
   ```
   utf8mb4_general_ci
   ```

4. **Klick auf "Anlegen"**

#### SQL-Datei importieren:

1. **Datenbank auswählen:**
   - Klick auf `glauser_serviceauftrag` (links)

2. **Import starten:**
   - Klick auf "Importieren" (oben im Menü)

3. **Datei auswählen:**
   - Klick auf "Datei auswählen"
   - Navigiere zu: `glauser-serviceauftrag/database/schema.sql`
   - Datei auswählen

4. **Import durchführen:**
   - Scroll nach unten
   - Klick auf "OK"
   - Warte auf "Import erfolgreich"

#### Kontrolle:

1. **Tabellen prüfen:**
   - Klick auf Datenbank `glauser_serviceauftrag` (links)
   - Du solltest sehen:
     ```
     ✅ user (2 Einträge)
     ✅ serviceauftrag (0 Einträge)
     ```

2. **User prüfen:**
   - Klick auf Tabelle `user`
   - Klick auf "Anzeigen"
   - Du solltest sehen: `admin` User

**Erfolg! Datenbank ist bereit!** ✅

---

### SCHRITT 4: BACKEND KONFIGURIEREN (2 Minuten)

#### Konfigurationsdatei prüfen:

1. **Öffne in Texteditor:**
   ```
   glauser-serviceauftrag/backend/config/database.php
   ```

2. **Prüfe die Einstellungen:**
   ```php
   $host = 'localhost';      // ✅ OK (Standard)
   $dbname = 'glauser_serviceauftrag';  // ✅ OK
   $username = 'root';       // ✅ OK (XAMPP Standard)
   $password = '';           // ✅ OK (XAMPP hat kein Passwort)
   ```

3. **Falls dein MySQL ein Passwort hat:**
   - Ändere: `$password = 'dein-passwort';`
   - Speichern!

#### .htaccess prüfen (optional):

```
glauser-serviceauftrag/backend/.htaccess
```

Sollte enthalten:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ $1.php [QSA,L]
```

---

### SCHRITT 5: BACKEND STARTEN (1 Minute)

#### Terminal/CMD öffnen:

**Windows:**
1. Explorer öffnen
2. Navigiere zu: `C:\xampp\htdocs\glauser-serviceauftrag\backend`
3. In der Adressleiste: Tippe `cmd` und Enter
4. CMD öffnet sich im richtigen Ordner

**macOS/Linux:**
```bash
cd /path/to/glauser-serviceauftrag/backend
```

#### Backend starten:

```bash
php -S localhost:8000
```

**Erwartete Ausgabe:**
```
[Sun Feb 02 13:00:00 2026] PHP 8.2.12 Development Server (http://localhost:8000) started
```

**Backend läuft jetzt!** ✅

#### Test im Browser:

```
http://localhost:8000/api/auth.php?action=check
```

**Erwartetes Ergebnis:**
```json
{
  "authenticated": false
}
```

**Wenn das erscheint: Backend funktioniert!** ✅

**Probleme?**

**"php: command not found":**
```bash
# Windows (XAMPP-PHP verwenden):
C:\xampp\php\php.exe -S localhost:8000

# macOS:
/Applications/XAMPP/xamppfiles/bin/php -S localhost:8000
```

**"Address already in use":**
- Port 8000 ist belegt
- Anderen Port nutzen: `php -S localhost:8001`
- Frontend muss dann auch angepasst werden!

---

### SCHRITT 6: NODE.JS INSTALLIEREN (3 Minuten)

1. **Download Node.js:**
   - https://nodejs.org/
   - Version: LTS (18.x oder höher)
   - Installer herunterladen

2. **Installieren:**
   - Installer ausführen
   - Alle Standard-Optionen OK
   - Installation abschließen

3. **Prüfen:**
   ```bash
   node --version
   # Sollte zeigen: v18.x.x oder höher
   
   npm --version
   # Sollte zeigen: 9.x.x oder höher
   ```

**Wenn beide Befehle funktionieren: Node.js ist bereit!** ✅

---

### SCHRITT 7: FRONTEND INSTALLIEREN (2 Minuten)

#### Terminal/CMD öffnen:

Navigiere zum Frontend-Ordner:

**Windows:**
```bash
cd C:\xampp\htdocs\glauser-serviceauftrag\frontend
```

**macOS/Linux:**
```bash
cd /path/to/glauser-serviceauftrag/frontend
```

#### Dependencies installieren:

```bash
npm install
```

**Das dauert 1-2 Minuten...**

**Erwartete Ausgabe:**
```
added 1500 packages in 90s
```

**Warnungen sind OK!** Nur Errors sind problematisch.

#### .env Datei erstellen:

1. **Kopiere Beispiel-Datei:**
   ```bash
   # Windows:
   copy .env.example .env
   
   # macOS/Linux:
   cp .env.example .env
   ```

2. **Falls .env.example fehlt, erstelle .env manuell:**
   
   Datei: `frontend/.env`
   ```env
   REACT_APP_API_URL=http://localhost:8000
   ```

3. **Speichern!**

---

### SCHRITT 8: FRONTEND STARTEN (1 Minute)

#### Im Frontend-Ordner:

```bash
npm start
```

**Erwartete Ausgabe:**
```
Compiled successfully!

You can now view serviceauftrag-frontend in the browser.

  Local:            http://localhost:3000
  On Your Network:  http://192.168.x.x:3000
```

**Browser öffnet sich automatisch!** 🎉

Falls nicht: Manuell öffnen: http://localhost:3000

---

### SCHRITT 9: LOGIN TESTEN (1 Minute)

#### Login-Seite sollte erscheinen:

1. **Eingabe:**
   ```
   Username: admin
   Passwort: admin123
   ```

2. **Klick auf "Anmelden"**

3. **Erwartetes Ergebnis:**
   - ✅ Login erfolgreich
   - ✅ Weiterleitung zur Hauptseite
   - ✅ Dashboard mit Statistiken sichtbar
   - ✅ "admin" oben rechts

**Wenn das funktioniert: INSTALLATION ERFOLGREICH!** 🎉

---

## ✅ INSTALLATIONS-CHECKLISTE

Nach Installation sollten folgende Punkte erfüllt sein:

- [ ] XAMPP läuft (Apache + MySQL grün)
- [ ] phpMyAdmin erreichbar (http://localhost/phpmyadmin)
- [ ] Datenbank `glauser_serviceauftrag` existiert
- [ ] Tabellen `user` und `serviceauftrag` vorhanden
- [ ] Admin-User in Tabelle `user` vorhanden
- [ ] Backend läuft auf http://localhost:8000
- [ ] Backend API antwortet (auth.php?action=check)
- [ ] Node.js installiert (node --version funktioniert)
- [ ] Frontend Dependencies installiert (node_modules/ existiert)
- [ ] Frontend läuft auf http://localhost:3000
- [ ] Login funktioniert (admin / admin123)
- [ ] Dashboard wird angezeigt

**Alle ✅? Perfekt! Installation abgeschlossen!** 🎉

---

## 🎯 NÄCHSTE SCHRITTE

### System testen:

1. **Auftrag erstellen:**
   - Klick "+ Neuer Auftrag"
   - Daten eingeben
   - Speichern

2. **PDF erstellen:**
   - Auftrag öffnen
   - "PDF erstellen" klicken

3. **Workflow durchspielen:**
   - Auftrag disponieren
   - Rapport erfassen
   - Freigeben
   - Verrechnen

### System anpassen:

1. **Weitere User anlegen:**
   - Als Admin einloggen
   - "Benutzerverwaltung" öffnen
   - Neuen User erstellen

2. **Design anpassen:**
   - `frontend/src/App.css` bearbeiten
   - Farben ändern
   - Logo einfügen

3. **Datenbank sichern:**
   - phpMyAdmin → Datenbank auswählen
   - "Exportieren"
   - SQL-Format
   - Speichern

---

## 🔧 TÄGLICHER START

**Jeden Tag wenn du weiterarbeiten willst:**

1. **XAMPP starten:**
   - XAMPP Control Panel
   - Apache Start
   - MySQL Start

2. **Backend starten:**
   ```bash
   cd backend
   php -S localhost:8000
   ```

3. **Frontend starten (neues Terminal):**
   ```bash
   cd frontend
   npm start
   ```

4. **Browser öffnen:**
   ```
   http://localhost:3000
   ```

5. **Login:**
   ```
   admin / admin123
   ```

**Fertig! Weiterarbeiten!** 🚀

---

## 🐛 HÄUFIGE PROBLEME

### Backend startet nicht

**Problem:** `Connection refused` oder `Access denied`

**Lösung:**
1. MySQL in XAMPP läuft?
2. Passwort korrekt in `backend/config/database.php`?
3. Datenbank `glauser_serviceauftrag` existiert?

**Test:**
```bash
C:\xampp\mysql\bin\mysql.exe -u root -p
# Passwort eingeben (oder Enter wenn leer)
SHOW DATABASES;
# → glauser_serviceauftrag sollte erscheinen
```

---

### Frontend startet nicht

**Problem:** `Module not found` oder `Failed to compile`

**Lösung:**
```bash
# Dependencies neu installieren
cd frontend
rm -rf node_modules package-lock.json
npm install

# Cache leeren
npm start -- --reset-cache
```

---

### Login funktioniert nicht

**Problem:** "Login fehlgeschlagen" obwohl Daten korrekt

**Lösung:**
1. **Backend läuft?**
   - http://localhost:8000/api/auth.php?action=check
   - Sollte JSON zurückgeben

2. **CORS-Fehler?**
   - Browser-Console öffnen (F12)
   - Fehler lesen
   - Evtl. CORS-Headers in Backend hinzufügen

3. **User existiert?**
   - phpMyAdmin → Tabelle `user`
   - Username `admin` vorhanden?
   - Passwort-Hash vorhanden?

---

### PDF funktioniert nicht

**Problem:** "PDF konnte nicht erstellt werden"

**Lösung:**
1. **Backend läuft?**
2. **Auftrag existiert?**
3. **Browser blockt Pop-ups?**
   - Pop-up-Blocker deaktivieren

---

## 📚 WEITERE HILFE

**Dokumentation:**
- README.md - Projekt-Übersicht
- dokumentation/ - Alle Diagramme

**Support:**
- GitHub Issues erstellen
- Berufsbildner fragen
- Berufsschule Support

---

## 🎓 FÜR SCHULABGABE

### System vorbereiten:

1. **Demo-Daten erstellen:**
   - 5-10 Testaufträge erfassen
   - Alle Status durchspielen
   - Screenshots machen

2. **Dokumentation checken:**
   - Alle Diagramme vorhanden?
   - Testkonzept aktuell?
   - README vollständig?

3. **Backup erstellen:**
   - Datenbank exportieren
   - Projekt-Ordner zippen
   - Auf USB-Stick sichern

4. **Präsentation vorbereiten:**
   - Live-Demo üben
   - Screenshots vorbereiten
   - Erklärung vorbereiten

---

**VIEL ERFOLG MIT DEM PROJEKT!** 🎉

Bei Problemen: Schritt-für-Schritt durchgehen und jeden Punkt abhaken!
