-- =======================================
-- SERVICEAUFTRAG MANAGEMENT SYSTEM
-- Datenbank-Schema für MySQL 8.0
-- =======================================

-- Datenbank erstellen (falls nicht vorhanden)
CREATE DATABASE IF NOT EXISTS glauser_serviceauftrag 
CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE glauser_serviceauftrag;

-- =======================================
-- TABELLE: user
-- =======================================

CREATE TABLE IF NOT EXISTS `user` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `vorname` VARCHAR(100) NOT NULL,
  `nachname` VARCHAR(100) NOT NULL,
  `email` VARCHAR(255) NULL,
  `role` ENUM('ADMIN', 'BEREICHSLEITER', 'MITARBEITER') NOT NULL DEFAULT 'MITARBEITER',
  `token` VARCHAR(255) NULL,
  `token_expires` DATETIME NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC),
  INDEX `idx_token` (`token` ASC),
  INDEX `idx_username` (`username` ASC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =======================================
-- TABELLE: serviceauftrag
-- =======================================

CREATE TABLE IF NOT EXISTS `serviceauftrag` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `auftragsnummer` VARCHAR(20) NOT NULL,
  `auftragsdatum` DATE NOT NULL,
  `auftragszeit` TIME NOT NULL,
  `status` ENUM('NEU', 'DISPONIERT', 'AUSGEFUEHRT', 'FREIGEGEBEN', 'VERRECHNET') NOT NULL DEFAULT 'NEU',
  
  -- Kundendaten
  `kunde_name` VARCHAR(255) NOT NULL,
  `kunde_strasse` VARCHAR(255) NOT NULL,
  `kunde_plz` VARCHAR(10) NOT NULL,
  `kunde_ort` VARCHAR(100) NOT NULL,
  `kunde_telefon` VARCHAR(30) NULL,
  `kunde_natel` VARCHAR(30) NULL,
  
  -- Objektadresse
  `objekt_dito` BOOLEAN NOT NULL DEFAULT FALSE,
  `objekt_strasse` VARCHAR(255) NULL,
  `objekt_plz` VARCHAR(10) NULL,
  `objekt_ort` VARCHAR(100) NULL,
  
  -- Rechnungsadresse
  `rechnung_dito` BOOLEAN NOT NULL DEFAULT FALSE,
  `rechnung_name` VARCHAR(255) NULL,
  `rechnung_strasse` VARCHAR(255) NULL,
  `rechnung_plz` VARCHAR(10) NULL,
  `rechnung_ort` VARCHAR(100) NULL,
  
  -- Arbeiten
  `arbeit_reparatur` BOOLEAN NOT NULL DEFAULT FALSE,
  `arbeit_sanitaer` BOOLEAN NOT NULL DEFAULT FALSE,
  `arbeit_heizung` BOOLEAN NOT NULL DEFAULT FALSE,
  `arbeit_garantie` BOOLEAN NOT NULL DEFAULT FALSE,
  `beschreibung` TEXT NULL,
  `terminwunsch` VARCHAR(255) NULL,
  
  -- Disposition
  `zugewiesen_an` INT NULL,
  `geplanter_termin` DATETIME NULL,
  `disponiert_am` DATETIME NULL,
  `disponiert_von` INT NULL,
  
  -- Rapport
  `ausgefuehrt_am` DATETIME NULL,
  `arbeitszeit_stunden` DECIMAL(5,2) NULL,
  `material_kosten` DECIMAL(8,2) NULL,
  `rapport_bemerkung` TEXT NULL,
  `rapport_erfasst_am` DATETIME NULL,
  `rapport_erfasst_von` INT NULL,
  
  -- Freigabe
  `freigegeben_am` DATETIME NULL,
  `freigegeben_von` INT NULL,
  
  -- Verrechnung
  `verrechnet_am` DATETIME NULL,
  `verrechnet_von` INT NULL,
  
  -- System
  `erstellt_von` INT NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`id`),
  UNIQUE INDEX `auftragsnummer_UNIQUE` (`auftragsnummer` ASC),
  INDEX `idx_auftragsnummer` (`auftragsnummer` ASC),
  INDEX `idx_status` (`status` ASC),
  INDEX `idx_zugewiesen_an` (`zugewiesen_an` ASC),
  INDEX `idx_auftragsdatum` (`auftragsdatum` ASC),
  INDEX `idx_kunde_name` (`kunde_name` ASC),
  
  CONSTRAINT `fk_serviceauftrag_zugewiesen_an`
    FOREIGN KEY (`zugewiesen_an`)
    REFERENCES `user` (`id`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    
  CONSTRAINT `fk_serviceauftrag_disponiert_von`
    FOREIGN KEY (`disponiert_von`)
    REFERENCES `user` (`id`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    
  CONSTRAINT `fk_serviceauftrag_rapport_erfasst_von`
    FOREIGN KEY (`rapport_erfasst_von`)
    REFERENCES `user` (`id`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    
  CONSTRAINT `fk_serviceauftrag_freigegeben_von`
    FOREIGN KEY (`freigegeben_von`)
    REFERENCES `user` (`id`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    
  CONSTRAINT `fk_serviceauftrag_verrechnet_von`
    FOREIGN KEY (`verrechnet_von`)
    REFERENCES `user` (`id`)
    ON DELETE SET NULL
    ON UPDATE CASCADE,
    
  CONSTRAINT `fk_serviceauftrag_erstellt_von`
    FOREIGN KEY (`erstellt_von`)
    REFERENCES `user` (`id`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- =======================================
-- DEMO-USER EINFÜGEN
-- =======================================

-- Passwort: admin123 (BCrypt Hash)
INSERT INTO `user` (`username`, `password_hash`, `vorname`, `nachname`, `email`, `role`) 
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'User', 'admin@glauser.ch', 'ADMIN');

-- =======================================
-- FERTIG!
-- =======================================

-- Tabellen prüfen
SHOW TABLES;

-- Struktur prüfen
DESCRIBE user;
DESCRIBE serviceauftrag;

-- Anzahl User prüfen
SELECT COUNT(*) as anzahl_users FROM user;

-- Erfolg!
SELECT 'Datenbank erfolgreich erstellt!' as status;
