# 🚀 Glauser Serviceauftrag Management System

> Komplettes Installations-Paket mit allem was du brauchst!

---

## 📦 WAS IST IN DIESEM PAKET?

```
glauser-serviceauftrag/
├── backend/               # PHP REST API
├── frontend/              # React Web-App
├── database/              # MySQL Schema + Demo-Daten
├── dokumentation/         # Alle UML-Diagramme, Tests, etc.
├── INSTALLATION.md        # ⭐ DETAILLIERTE INSTALLATIONS-ANLEITUNG
├── README.md              # Diese Datei
└── .gitignore             # Für GitHub Upload
```

---

## ⚡ SCHNELLSTART

**Komplett installieren in 15 Minuten:**

1. **INSTALLATION.md öffnen** ← HIER STEHT ALLES DRIN!
2. Schritt-für-Schritt folgen
3. Fertig!

---

## 📋 VORAUSSETZUNGEN

- ✅ XAMPP 8.2+ (Apache + MySQL)
- ✅ Node.js 18+
- ✅ Browser (Chrome/Firefox/Edge)
- ✅ 15 Minuten Zeit

---

## 🎯 WICHTIGSTE SCHRITTE

### 1. XAMPP starten
```
Apache: Start
MySQL: Start
```

### 2. Datenbank erstellen
```
http://localhost/phpmyadmin
→ Neue Datenbank: glauser_serviceauftrag
→ SQL importieren: database/schema.sql
```

### 3. Backend starten
```bash
cd backend
php -S localhost:8000
```

### 4. Frontend starten
```bash
cd frontend
npm install
npm start
```

### 5. Login
```
http://localhost:3000
Username: admin
Passwort: admin123
```

---

## ✨ FEATURES

- ✅ Auftragsverwaltung (Erfassen, Bearbeiten, Löschen)
- ✅ Disposition (Mitarbeiter zuweisen, Termin planen)
- ✅ Rapport (Arbeitszeit + Materialkosten erfassen)
- ✅ Freigabe-Workflow (Bereichsleiter)
- ✅ Verrechnung (Admin)
- ✅ PDF-Export
- ✅ Dashboard mit Statistiken
- ✅ Filter & Suche
- ✅ 3 Rollen (Admin, Bereichsleiter, Mitarbeiter)

---

## 📚 DOKUMENTATION

**Alles im `dokumentation/` Ordner:**

- UseCase-Diagramm
- Klassendiagramm
- ERD (Entity Relationship Diagram)
- ERM (Erweitertes Relationenmodell)
- UI-Skizzen (3 Screens)
- Testkonzept (45 Testfälle)

**Alle Diagramme öffnen mit:** https://app.diagrams.net

---

## 🔧 TECHNOLOGIE

**Backend:**
- PHP 8.2.12
- MySQL 8.0
- REST API

**Frontend:**
- React 18.3.1
- React Router 6
- Axios

**Entwicklung:**
- XAMPP
- Node.js
- npm

---

## 📖 HILFE BENÖTIGT?

**1. INSTALLATION.md lesen** ← Schritt-für-Schritt Anleitung
   - Alle Schritte erklärt
   - Screenshots-Beschreibungen
   - Fehlerbehebung
   - Checklisten

**2. Probleme?**
   - Siehe "Häufige Probleme" in INSTALLATION.md
   - Browser-Console prüfen (F12)
   - phpMyAdmin öffnen

**3. Support:**
   - Berufsbildner fragen
   - Berufsschule Support
   - Dokumentation durchlesen

---

## 🎓 FÜR ABGABE

**Projekt ist abgabefertig!**

- ✅ Vollständige Dokumentation
- ✅ UML-Diagramme
- ✅ Datenbank-Schema
- ✅ Testkonzept (45 Tests)
- ✅ Installation-Anleitung
- ✅ Funktionierendes System

**Verwendbar für:**
- Lehrjahr-Abgabe
- Portfolio
- Bewerbungen
- Präsentationen

---

## 🚀 AUF GITHUB HOCHLADEN

**Optional: Projekt auf GitHub:**

1. **GitHub Account erstellen**
2. **Neues Repository erstellen**
3. **Git initialisieren:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/DEINUSERNAME/glauser-serviceauftrag.git
   git push -u origin main
   ```

**Tipp:** `.gitignore` ist bereits enthalten!

---

## 📧 PROJEKT-INFO

**Entwickelt als:** Lehrjahr-Projekt (2. Lehrjahr)
**Zeitraum:** Januar 2026
**Firma:** Glauser Illnau AG
**Bereich:** Applikationsentwicklung EFZ

---

## ⭐ LOS GEHT'S!

**→ Öffne INSTALLATION.md und folge den Schritten!**

**In 15 Minuten ist alles installiert und läuft!** 🎉

---

## 📝 LIZENZ

Projekt entwickelt als Lehrjahr-Projekt.
Alle Rechte vorbehalten © 2026

---

**VIEL ERFOLG!** 🚀
