# ⚡ QUICK START - 15 Minuten Installation

Schnellste Methode um das System zum Laufen zu bringen!

---

## ✅ CHECKLISTE VORHER

Stelle sicher, dass du folgendes hast:

- [ ] XAMPP 8.2+ installiert
- [ ] Node.js 18+ installiert
- [ ] ZIP-Datei entpackt
- [ ] 15 Minuten Zeit

**Noch nicht installiert? Siehe INSTALLATION.md für Details!**

---

## 🚀 INSTALLATION IN 9 SCHRITTEN

### 1️⃣ XAMPP STARTEN (1 Min)

```
1. XAMPP Control Panel öffnen
2. Apache: Start ✅
3. MySQL: Start ✅
```

**Beide grün? Weiter!**

---

### 2️⃣ DATENBANK ERSTELLEN (2 Min)

```
1. Browser öffnen: http://localhost/phpmyadmin
2. "Neu" klicken
3. Name: glauser_serviceauftrag
4. Zeichensatz: utf8mb4_general_ci
5. "Anlegen" klicken
```

---

### 3️⃣ SQL IMPORTIEREN (2 Min)

```
1. Datenbank "glauser_serviceauftrag" auswählen
2. "Importieren" klicken (oben)
3. "Datei auswählen" klicken
4. database/schema.sql auswählen
5. "OK" klicken (unten)
6. Warten bis "Import erfolgreich"
```

**Tabellen user + serviceauftrag sichtbar? Weiter!**

---

### 4️⃣ BACKEND STARTEN (2 Min)

**Terminal/CMD öffnen im backend-Ordner:**

```bash
cd C:\xampp\htdocs\glauser-serviceauftrag\backend
php -S localhost:8000
```

**Läuft? Lass es offen! Neues Terminal für nächsten Schritt!**

**Test:** http://localhost:8000/api/auth.php?action=check

---

### 5️⃣ FRONTEND INSTALLIEREN (3 Min)

**Neues Terminal/CMD im frontend-Ordner:**

```bash
cd C:\xampp\htdocs\glauser-serviceauftrag\frontend
npm install
```

**Warte bis "added XXX packages"**

---

### 6️⃣ .ENV ERSTELLEN (1 Min)

**Im frontend-Ordner:**

```bash
# Windows:
copy .env.example .env

# macOS/Linux:
cp .env.example .env
```

**Falls .env.example fehlt, erstelle .env:**

```env
REACT_APP_API_URL=http://localhost:8000
```

---

### 7️⃣ FRONTEND STARTEN (2 Min)

**Im frontend-Ordner:**

```bash
npm start
```

**Browser öffnet sich automatisch!**

---

### 8️⃣ LOGIN (1 Min)

```
Username: admin
Passwort: admin123
```

**"Anmelden" klicken**

---

### 9️⃣ FERTIG! 🎉

**Du solltest jetzt sehen:**
- ✅ Dashboard
- ✅ Statistiken (5 Boxen)
- ✅ "admin" oben rechts
- ✅ "+ Neuer Auftrag" Button

**ALLES LÄUFT!** 🎉

---

## 🧪 SCHNELLTEST

### 1. Auftrag erstellen

```
1. "+ Neuer Auftrag" klicken
2. Name: Test GmbH
3. Strasse: Teststrasse 1
4. PLZ: 8000
5. Ort: Zürich
6. Reparatur: ☑
7. "Speichern"
```

**Auftrag erscheint in Liste? ✅**

---

### 2. PDF erstellen

```
1. Auftrag öffnen (klicken)
2. "PDF erstellen" klicken
3. PDF öffnet sich
```

**PDF zeigt Daten? ✅**

---

## 🐛 PROBLEME?

### Apache startet nicht
```
→ Port 80 belegt (Skype schließen!)
→ Siehe INSTALLATION.md → "Probleme"
```

### MySQL startet nicht
```
→ Port 3306 belegt
→ Siehe INSTALLATION.md → "Probleme"
```

### Backend startet nicht
```
→ MySQL läuft nicht
→ Datenbank nicht erstellt
→ Siehe INSTALLATION.md → "Backend startet nicht"
```

### Frontend startet nicht
```
cd frontend
rm -rf node_modules package-lock.json
npm install
npm start
```

### Login funktioniert nicht
```
→ Backend läuft?
→ URL korrekt in .env?
→ Browser Console (F12) prüfen
```

---

## 📱 TÄGLICHER START

**Nächstes Mal schneller starten:**

```bash
# 1. XAMPP starten (Apache + MySQL)

# 2. Backend (Terminal 1):
cd backend
php -S localhost:8000

# 3. Frontend (Terminal 2):
cd frontend
npm start

# 4. Login: admin / admin123
```

**Nur 2 Minuten!** ⚡

---

## 📚 MEHR HILFE?

**Detaillierte Anleitung:** INSTALLATION.md
- Schritt-für-Schritt mit Screenshots-Beschreibungen
- Alle Probleme erklärt
- Checklisten
- Fehlerbehebung

**README.md:** Projekt-Übersicht

**dokumentation/:** Alle Diagramme und Tests

---

## ✅ ERFOLGS-CHECKLISTE

Nach Quick Start sollten diese Punkte ✅ sein:

- [ ] XAMPP läuft (Apache + MySQL)
- [ ] phpMyAdmin erreichbar
- [ ] Datenbank erstellt
- [ ] Tabellen vorhanden
- [ ] Backend läuft (localhost:8000)
- [ ] Frontend läuft (localhost:3000)
- [ ] Login funktioniert
- [ ] Dashboard sichtbar
- [ ] Auftrag erstellen funktioniert
- [ ] PDF erstellen funktioniert

**Alle ✅? Perfekt installiert!** 🎉

---

**Bei Problemen:** Siehe INSTALLATION.md für detaillierte Hilfe!

**VIEL SPASS MIT DEM SYSTEM!** 🚀
